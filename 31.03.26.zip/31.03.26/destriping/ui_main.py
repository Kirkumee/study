import os
import numpy as np
from PyQt5.QtWidgets import (
    QMainWindow, QWidget, QVBoxLayout, QHBoxLayout,
    QPushButton, QLabel, QFileDialog, QScrollArea,
    QStatusBar, QMessageBox
)
from PyQt5.QtCore import Qt, QThread, pyqtSignal
from PyQt5.QtGui import QImage, QPixmap, QWheelEvent

from destripe import destripe_blocks

class WorkerThread(QThread):
    done  = pyqtSignal(np.ndarray)
    error = pyqtSignal(str)

    def __init__(self, img: np.ndarray):
        super().__init__()
        self.img = img

    def run(self):
        try:
            self.done.emit(destripe_blocks(self.img))
        except Exception as e:
            self.error.emit(str(e))

class ZoomLabel(QLabel):
    def __init__(self, parent=None):
        super().__init__(parent)
        self.setAlignment(Qt.AlignCenter)
        self._pixmap_orig = None
        self._zoom = 1.0
        self.setMouseTracking(True)

    def set_image_pixmap(self, px: QPixmap):
        self._pixmap_orig = px
        self._zoom = 1.0
        self._apply_zoom()

    def clear_image(self):
        self._pixmap_orig = None
        self._zoom = 1.0
        self.clear()

    def wheelEvent(self, event: QWheelEvent):
        if self._pixmap_orig is None:
            return
        delta = event.angleDelta().y()
        factor = 1.15 if delta > 0 else 1 / 1.15
        self._zoom = max(0.1, min(self._zoom * factor, 20.0))
        self._apply_zoom()
        event.accept()

    def _apply_zoom(self):
        if self._pixmap_orig is None:
            return
        w = int(self._pixmap_orig.width() * self._zoom)
        h = int(self._pixmap_orig.height() * self._zoom)
        scaled = self._pixmap_orig.scaled(w, h, Qt.KeepAspectRatio, Qt.SmoothTransformation)
        self.setPixmap(scaled)
        self.resize(max(w, self.parentWidget().width() if self.parentWidget() else w),
                    max(h, self.parentWidget().height() if self.parentWidget() else h))

class MainWindow(QMainWindow):
    def __init__(self):
        super().__init__()
        self.setWindowTitle("Destriping")
        self.resize(960, 700)
        self.setMinimumSize(640, 480)

        self._img_original = None
        self._img_current = None
        self._fname = ""
        self._worker = None

        self._build_ui()

    def _build_ui(self):
        self._status = QStatusBar()
        self.setStatusBar(self._status)

        central = QWidget()
        self.setCentralWidget(central)
        root = QHBoxLayout(central)
        root.setContentsMargins(10, 10, 10, 10)
        root.setSpacing(10)

        left = QVBoxLayout()
        left.setSpacing(12)

        btn_open = QPushButton("Открыть")
        btn_open.setMinimumHeight(40)
        btn_open.clicked.connect(self._open_file)
        left.addWidget(btn_open)

        self._btn_apply = QPushButton("Улучшить")
        self._btn_apply.setMinimumHeight(52)
        self._btn_apply.setEnabled(False)
        self._btn_apply.clicked.connect(self._apply)
        left.addWidget(self._btn_apply)

        self._btn_save = QPushButton("Сохранить")
        self._btn_save.setMinimumHeight(42)
        self._btn_save.setEnabled(False)
        self._btn_save.clicked.connect(self._save)
        left.addWidget(self._btn_save)

        left.addSpacing(20)
        self._lbl_info = QLabel("")
        self._lbl_info.setWordWrap(True)
        left.addWidget(self._lbl_info)

        left.addStretch()
        root.addLayout(left, 0)

        self._img_label = ZoomLabel()
        self._img_label.setText("Место для ИК-снимка")
        self._img_label.setAlignment(Qt.AlignCenter)
        self._img_label.setStyleSheet("color:gray;font-size:14px;border:1px dashed #aaa;padding:30px;")

        self._scroll = QScrollArea()
        self._scroll.setWidget(self._img_label)
        self._scroll.setWidgetResizable(False)
        self._scroll.setAlignment(Qt.AlignCenter)
        root.addWidget(self._scroll, 1)

    def _open_file(self):
        fname, _ = QFileDialog.getOpenFileName(
            self, "Открыть изображение", "",
            "Изображения (*.bmp *.tif *.tiff *.png *.jpg *.jpeg);;All Files (*.*)"
        )
        if not fname:
            return
        try:
            from PIL import Image
            with Image.open(fname) as im:
                arr = np.array(im)

                if arr.dtype == np.uint16:
                    arr_f = arr.astype(np.float64)
                    lo, hi = arr_f.min(), arr_f.max()
                    if hi > lo:
                        arr = np.clip((arr_f - lo) / (hi - lo) * 255.0, 0, 255).astype(np.uint8)
                    else:
                        arr = np.zeros_like(arr, dtype=np.uint8)

                if arr.ndim == 2:
                    arr = np.stack([arr, arr, arr], axis=2)
                elif arr.shape[2] == 1:
                    arr = np.repeat(arr, 3, axis=2)

                self._img_original = arr
                self._img_current = arr.copy()
                self._fname = fname

                self._show(arr)
                self._btn_apply.setEnabled(True)
                self._btn_save.setEnabled(False)

                short = os.path.basename(fname)
                h, w = arr.shape[:2]
                self._lbl_info.setText(f"{short}\n{w} × {h} px")
                self._status.showMessage(f"Открыт: {short}")
        except Exception as e:
            QMessageBox.critical(self, "Ошибка", f"Не удалось открыть:\n{e}")

    def _apply(self):
        if self._img_original is None:
            return
        self._btn_apply.setEnabled(False)
        self._btn_save.setEnabled(False)
        self._status.showMessage("Убираем полосы")

        self._worker = WorkerThread(self._img_original)
        self._worker.done.connect(self._on_done)
        self._worker.error.connect(self._on_error)
        self._worker.start()

    def _on_done(self, result: np.ndarray):
        self._img_current = result
        self._show(result)
        self._btn_apply.setEnabled(True)
        self._btn_save.setEnabled(True)
        self._status.showMessage("Готово")

    def _on_error(self, msg: str):
        self._btn_apply.setEnabled(True)
        self._status.showMessage("Ошибка")
        QMessageBox.critical(self, "Ошибка", msg)

    def _save(self):
        if self._img_current is None:
            return
        default = ""
        if self._fname:
            base, ext = os.path.splitext(self._fname)
            default = base + "_destriped" + ext

        fname, _ = QFileDialog.getSaveFileName(
            self, "Сохранить", default,
            "PNG (*.png);;BMP (*.bmp);;TIFF (*.tif *.tiff);;JPEG (*.jpg)"
        )
        if not fname:
            return
        try:
            from PIL import Image
            Image.fromarray(self._img_current).save(fname)
            self._status.showMessage(f"Сохранено: {os.path.basename(fname)}")
        except Exception as e:
            QMessageBox.critical(self, "Ошибка", f"Не удалось сохранить:\n{e}")

    def _show(self, arr: np.ndarray):
        arr = np.ascontiguousarray(np.clip(arr, 0, 255).astype(np.uint8))
        if arr.ndim == 2:
            arr = np.stack([arr, arr, arr], axis=2)
        elif arr.shape[2] == 1:
            arr = np.repeat(arr, 3, axis=2)
        arr = arr[:, :, :3]
        h, w = arr.shape[:2]
        qimg = QImage(arr.data, w, h, w * 3, QImage.Format_RGB888)
        px = QPixmap.fromImage(qimg.copy())
        self._img_label.set_image_pixmap(px)
        self._img_label.setStyleSheet("")
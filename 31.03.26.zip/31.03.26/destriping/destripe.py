import numpy as np
from scipy import ndimage
import warnings
warnings.filterwarnings("ignore", category=RuntimeWarning)

_STRIPE = 183

def destripe_blocks(img):
    if not isinstance(img, np.ndarray):
        img = np.array(img)
    if img.ndim == 2:
        arr = img.astype(np.float32)[:, :, np.newaxis]
    else:
        arr = img.astype(np.float32)
    h, w, c = arr.shape
    result = np.zeros_like(arr)
    
    for ch in range(c):
        band = arr[:, :, ch].copy()
        planet_mask = _create_planet_mask(band)
        centers = _center_per_stripe(band, planet_mask)
        if len(centers) >= 4:
            half_jump = _compute_half_jump(centers)
            if abs(half_jump) >= 0.5:
                band = _shift_correction(band, half_jump, planet_mask)
        
        result[:, :, ch] = band
    
    return np.clip(result, 0, 255).astype(np.uint8)

def _create_planet_mask(band, threshold_percentile=70):
    mask = band > np.percentile(band, threshold_percentile)
    mask = ndimage.binary_closing(mask, structure=np.ones((15, 15)))
    mask = ndimage.binary_opening(mask, structure=np.ones((5, 5)))
    mask = ndimage.binary_dilation(mask, iterations=3)
    return mask

def _center_per_stripe(band, planet_mask):
    h = band.shape[0]
    centers = []
    step = _STRIPE
    
    for i in range(0, h, step):
        r0, r1 = i, min(i + step, h)
        lefts, rights = [], []
        for r in range(r0, r1, 3):
            if not np.any(planet_mask[r]):
                continue
                
            row = band[r]
            mask_row = planet_mask[r]
            planet_indices = np.where(mask_row)[0]
            if len(planet_indices) > 10:
                lefts.append(float(planet_indices[0]))
                rights.append(float(planet_indices[-1]))
        
        if lefts and rights:
            center = (np.median(lefts) + np.median(rights)) / 2.0
            centers.append(center)
        else:
            centers.append(np.nan)
    
    return np.array(centers)

def _compute_half_jump(centers):
    jumps = []
    centers_clean = centers[~np.isnan(centers)]
    if len(centers_clean) < 3:
        return 0.0
    for i in range(0, len(centers_clean) - 1, 2):
        if i + 1 < len(centers_clean):
            j = centers_clean[i + 1] - centers_clean[i]
            if abs(j) < 30:
                jumps.append(j)
    if not jumps:
        return 0.0
    return np.median(jumps) / 2.0

def _shift_correction(band, half_jump, planet_mask):
    h, w = band.shape
    out = band.copy()
    step = _STRIPE
    xs = np.arange(w, dtype=np.float32)
    
    for i in range(0, h, step):
        r0, r1 = i, min(i + step, h)
        block_idx = i // step
        
        if block_idx < 10:
            weight = block_idx / 10.0
        else:
            weight = 1.0
        
        shift = (half_jump if block_idx % 2 == 0 else -half_jump) * weight
        
        if abs(shift) < 0.5:
            continue

        src = np.clip(xs - shift, 0, w - 1)
        x0 = np.floor(src).astype(np.int32)
        x1 = np.minimum(x0 + 1, w - 1)
        t = (src - x0).astype(np.float32)
        rows = np.arange(r0, r1)
        for r in rows:
            if np.any(planet_mask[r]):
                out[r] = band[r][x0] * (1 - t) + band[r][x1] * t
            else:
                out[r] = band[r]
    return out
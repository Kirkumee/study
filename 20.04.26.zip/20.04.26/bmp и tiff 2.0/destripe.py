import numpy as np
from scipy.ndimage import uniform_filter1d, binary_dilation, median_filter, gaussian_filter
import warnings
warnings.filterwarnings("ignore", category=RuntimeWarning)

_STRIPE = 183
_WINDOW = 21

def destripe_blocks(img, heavy=False):
    if not isinstance(img, np.ndarray):
        img = np.array(img)
    arr = img.astype(np.float32)
    orig_ndim = img.ndim
    if arr.ndim == 2:
        arr = arr[:, :, np.newaxis]
    h, w, c = arr.shape

    flat = arr.ravel()
    p2 = float(np.percentile(flat, 2))
    p8 = float(np.percentile(flat, 8))
    bg_level = float(np.mean(flat[flat < p8]))
    bg_std = float(np.std(flat[flat < p8])) if np.any(flat < p8) else 1.0
    
    bg_thresh = max(p2 + 20.0, bg_level + 4.2 * bg_std, 22.0)

    bg_mask = np.all(arr < bg_thresh, axis=2)
    bg_mask = binary_dilation(bg_mask, iterations=4)

    result = np.zeros_like(arr)
    for ch in range(c):
        if heavy:
            result[:, :, ch] = _correct_band_veryheavy(arr[:, :, ch], bg_thresh)
        else:
            result[:, :, ch] = _correct_band(arr[:, :, ch], bg_thresh)

    result[bg_mask] = 0.0

    for ch in range(c):
        result[:, :, ch] = _clean_strong(result[:, :, ch], bg_thresh)

    out = np.clip(result, 0, 255).astype(np.uint8)
    if orig_ndim == 2:
        out = out[:, :, 0]
    return out

def _correct_band(band, bg_thresh):
    h, w = band.shape
    n = (h + _STRIPE - 1) // _STRIPE

    intra = band.copy()
    for i in range(n):
        r0, r1 = i * _STRIPE, min((i + 1) * _STRIPE, h)
        intra[r0:r1] = _normalize_block(band[r0:r1], bg_thresh)

    bm = np.full(n, np.nan)
    for i in range(n):
        r0, r1 = i * _STRIPE, min((i + 1) * _STRIPE, h)
        px = intra[r0:r1][intra[r0:r1] > bg_thresh]
        if px.size > 25:
            bm[i] = np.median(px)

    valid_mask = ~np.isnan(bm)
    if valid_mask.sum() < 3:
        return intra

    valid_vals = bm[valid_mask]
    valid_ids = np.where(valid_mask)[0]
    trend_vals = median_filter(valid_vals, size=5, mode='reflect')
    trend_full = np.interp(np.arange(n, dtype=float), valid_ids.astype(float), trend_vals)

    out = intra.copy()
    for i in range(n):
        if np.isnan(bm[i]):
            continue
        r0, r1 = i * _STRIPE, min((i + 1) * _STRIPE, h)
        delta = trend_full[i] - bm[i]
        pm = intra[r0:r1] > bg_thresh * 0.85
        out[r0:r1][pm] += delta
    return out

def _correct_band_veryheavy(band, bg_thresh):
    h, w = band.shape
    n = (h + _STRIPE - 1) // _STRIPE

    intra = band.copy()
    for i in range(n):
        r0, r1 = i * _STRIPE, min((i + 1) * _STRIPE, h)
        intra[r0:r1] = _normalize_block(band[r0:r1], bg_thresh)

    bm = np.full(n, np.nan)
    for i in range(n):
        r0, r1 = i * _STRIPE, min((i + 1) * _STRIPE, h)
        px = intra[r0:r1][intra[r0:r1] > bg_thresh * 0.75]
        if px.size > 15:
            bm[i] = np.median(px)

    valid_mask = ~np.isnan(bm)
    if valid_mask.sum() < 3:
        return intra

    valid_vals = bm[valid_mask]
    valid_ids = np.where(valid_mask)[0]
    trend_vals = median_filter(valid_vals, size=11, mode='reflect')
    trend_full = np.interp(np.arange(n, dtype=float), valid_ids.astype(float), trend_vals)

    out = intra.copy()
    for i in range(n):
        if np.isnan(bm[i]):
            continue
        r0, r1 = i * _STRIPE, min((i + 1) * _STRIPE, h)
        delta = (trend_full[i] - bm[i]) * 1.25
        pm = intra[r0:r1] > bg_thresh * 0.75
        out[r0:r1][pm] += delta
    return out

def _normalize_block(block, bg_thresh):
    bh, bw = block.shape
    row_mean = np.empty(bh)
    row_std = np.empty(bh)

    for i in range(bh):
        row = block[i]
        signal = row[row > bg_thresh]
        if signal.size >= 5:
            row_mean[i] = signal.mean()
            row_std[i] = signal.std(ddof=1) + 1e-6
        else:
            row_mean[i] = row.mean()
            row_std[i] = row.std(ddof=1) + 1e-6

    win = min(_WINDOW, bh if bh % 2 == 1 else bh - 1)
    win = max(win, 7)

    smooth_mean = uniform_filter1d(row_mean, size=win, mode='reflect')
    smooth_std = uniform_filter1d(row_std, size=win, mode='reflect')

    gain = np.clip(smooth_std / row_std, 0.7, 1.6)
    offset = smooth_mean - row_mean * gain

    bg_rows = row_mean < bg_thresh * 0.9
    gain[bg_rows] = 1.0
    offset[bg_rows] = 0.0

    return block * gain[:, np.newaxis] + offset[:, np.newaxis]

def _clean_strong(band, bg_thresh):
    dark = (band < 15) & (band > 0)
    from scipy.ndimage import binary_opening, binary_closing
    cleaned = binary_opening(dark, structure=np.ones((2, 2)))
    cleaned = binary_closing(cleaned, structure=np.ones((3, 3)))

    band = band.copy()
    if np.any(band > bg_thresh):
        signal_median = float(np.median(band[band > bg_thresh]))
        band[cleaned] = signal_median

    edge = binary_dilation(cleaned, iterations=1)
    smoothed = gaussian_filter(band, sigma=0.7)
    band[edge] = smoothed[edge]
    
    return band
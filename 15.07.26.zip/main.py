import tkinter as tk
from tkinter import ttk, filedialog, messagebox
import threading
import numpy as np
import scipy.io as sio
from sklearn.decomposition import IncrementalPCA
from sklearn.cluster import KMeans
from sklearn.mixture import GaussianMixture
from sklearn.metrics import f1_score, precision_score, recall_score
from scipy.optimize import linear_sum_assignment
from scipy.ndimage import uniform_filter
import matplotlib.pyplot as plt
from matplotlib.backends.backend_tkagg import FigureCanvasTkAgg
import spectral
import warnings
warnings.filterwarnings('ignore')

CLASS_NAMES = ['Асфальт','Луга','Гравий','Деревья','Металл. листы',
               'Голая почва','Битум','Кирпич','Тени']
N = 9

def match(y_pred, y_true, n):
    cost = np.zeros((n, n))
    for i in range(n):
        for j in range(n):
            cost[i,j] = -np.sum((y_pred==i)&(y_true==j))
    r, c = linear_sum_assignment(cost)
    m = dict(zip(r, c))
    return np.array([m[l] for l in y_pred])

def prepare(hsi_path, gt_path):
    HSI = sio.loadmat(hsi_path)['paviaU']
    GT  = sio.loadmat(gt_path)['paviaU_gt']
    h, w = GT.shape
    flat = HSI.reshape(-1, HSI.shape[2])
    pca = IncrementalPCA(n_components=20)
    for b in np.array_split(flat, 256):
        pca.partial_fit(b)
    X = pca.transform(flat)
    X3 = X.reshape(h, w, 20)
    sm = np.zeros_like(X3)
    for ch in range(20):
        sm[:,:,ch] = uniform_filter(X3[:,:,ch], size=5)
    Xss = np.concatenate([X3, sm], axis=2).reshape(-1, 40)
    mask = GT.flatten() > 0
    Xraw = HSI.reshape(-1, HSI.shape[2])[mask].astype(float)
    Xraw = (Xraw - Xraw.min()) / (Xraw.max() - Xraw.min() + 1e-8)
    rgb = HSI[:,:,[30,20,10]].astype(float)
    rgb = (rgb - rgb.min()) / (rgb.max() - rgb.min())
    return {'Xss': Xss[mask], 'Xraw': Xraw,
            'y': GT.flatten()[mask]-1,
            'mask': mask, 'h': h, 'w': w, 'GT': GT, 'rgb': rgb}

def get_metrics(y_true, y_pred):
    p = precision_score(y_true, y_pred, average='weighted', zero_division=0)
    r = recall_score(y_true, y_pred, average='weighted', zero_division=0)
    f = f1_score(y_true, y_pred, average='weighted', zero_division=0)
    return p, r, f

def colormap(pred, mask, h, w):
    spy = np.array(spectral.spy_colors)/255.0
    img = np.zeros((h*w, 3))
    img[mask] = spy[pred+1]
    return img.reshape(h, w, 3)

def gt_colormap(GT):
    spy = np.array(spectral.spy_colors)/255.0
    h, w = GT.shape
    img = np.zeros((h*w, 3))
    for c in range(1, 10):
        img[GT.flatten()==c] = spy[c]
    return img.reshape(h, w, 3)

# ui
class App(tk.Tk):
    def __init__(self):
        super().__init__()
        self.title("Кластеризация — Pavia University")
        self.state('zoomed')
        self.hsi = self.gt_path = self.data = self.pred = self.last_name = None
        self._build()

    def _build(self):
        # Левая панель
        left = ttk.Frame(self, width=200)
        left.pack(side='left', fill='y', padx=6, pady=6)
        left.pack_propagate(False)

        self.lbl_hsi = ttk.Label(left, text="HSI: не выбран", foreground='gray', wraplength=190)
        self.lbl_hsi.pack(anchor='w')
        ttk.Button(left, text="Открыть HSI", command=self._open_hsi).pack(fill='x', pady=2)

        self.lbl_gt = ttk.Label(left, text="GT: не выбран", foreground='gray', wraplength=190)
        self.lbl_gt.pack(anchor='w', pady=(6,0))
        ttk.Button(left, text="Открыть GT", command=self._open_gt).pack(fill='x', pady=2)
        ttk.Button(left, text="Загрузить данные", command=self._prepare).pack(fill='x', pady=6)

        ttk.Separator(left).pack(fill='x', pady=4)
        ttk.Label(left, text="Кластеризация:", font=('',9,'bold')).pack(anchor='w')
        ttk.Button(left, text="K-Means", command=lambda: self._run('km')).pack(fill='x', pady=2)
        ttk.Button(left, text="GMM", command=lambda: self._run('gmm')).pack(fill='x', pady=2)
        ttk.Button(left, text="K-Means + seed…",command=lambda: self._run('kms')).pack(fill='x', pady=2)

        ttk.Separator(left).pack(fill='x', pady=4)
        self.lbl_res = ttk.Label(left, text="", justify='left', wraplength=190)
        self.lbl_res.pack(anchor='w')

        # Правая панель (вкладки)
        self.nb = ttk.Notebook(self)
        self.nb.pack(side='right', fill='both', expand=True, padx=6, pady=6)

        self.fig_src, self.ax_src, self.cv_src = self._make_tab("Исходное изображение")
        self.fig_gt2, self.ax_gt2, self.cv_gt2 = self._make_tab("Эталонная маска")
        self.fig_res, self.ax_res2, self.cv_res = self._make_tab("Результат")
        self.fig_cmp, self.ax_cmp, self.cv_cmp = self._make_grid_tab("GT vs Результат", 1, 3)
        self.fig_sp,  self.ax_sp, self.cv_sp  = self._make_grid_tab("Спектры кластеров", 3, 3)
        self.fig_cg,  self.ax_cg, self.cv_cg  = self._make_grid_tab("Кластер vs Эталон", 3, 3)
        self.fig_gts, self.ax_gts, self.cv_gts = self._make_tab("Спектры GT")
        self.fig_hm,  self.ax_hm, self.cv_hm  = self._make_tab("Карта сходства")

    def _make_tab(self, title):
        f = ttk.Frame(self.nb)
        self.nb.add(f, text=title)
        fig = plt.Figure(tight_layout=True)
        ax  = fig.add_subplot(111)
        ax.axis('off')
        cv  = FigureCanvasTkAgg(fig, master=f)
        cv.get_tk_widget().pack(fill='both', expand=True)
        return fig, ax, cv

    def _make_grid_tab(self, title, rows, cols):
        f = ttk.Frame(self.nb)
        self.nb.add(f, text=title)
        fig = plt.Figure(tight_layout=True)
        axes = [fig.add_subplot(rows, cols, i+1) for i in range(rows*cols)]
        for ax in axes: ax.axis('off')
        cv = FigureCanvasTkAgg(fig, master=f)
        cv.get_tk_widget().pack(fill='both', expand=True)
        return fig, axes, cv

    # Файлы
    def _open_hsi(self):
        p = filedialog.askopenfilename(filetypes=[("MAT","*.mat")])
        if p:
            self.hsi = p
            self.lbl_hsi.config(text="HSI: "+p.split('/')[-1], foreground='black')

    def _open_gt(self):
        p = filedialog.askopenfilename(filetypes=[("MAT","*.mat")])
        if p:
            self.gt_path = p
            self.lbl_gt.config(text="GT: "+p.split('/')[-1], foreground='black')

    def _prepare(self):
        if not self.hsi or not self.gt_path:
            messagebox.showwarning("", "Выберите оба файла."); return
        def work():
            try:
                self.data = prepare(self.hsi, self.gt_path)
                self.after(0, self._draw_src_gt)
                self.after(0, lambda: self.lbl_res.config(text="Данные загружены.\nВыберите метод."))
            except Exception as e:
                self.after(0, lambda: messagebox.showerror("Ошибка", str(e)))
        threading.Thread(target=work, daemon=True).start()

    def _draw_src_gt(self):
        d = self.data
        self.ax_src.clear()
        self.ax_src.imshow(d['rgb']); self.ax_src.axis('off')
        self.ax_src.set_title("Исходное RGB")
        self.cv_src.draw()

        self.ax_gt2.clear()
        self.ax_gt2.imshow(gt_colormap(d['GT'])); self.ax_gt2.axis('off')
        self.ax_gt2.set_title("Эталонная маска (GT)")
        self.cv_gt2.draw()
        self._draw_gt_spectra()
        self.nb.select(0)

    # Кластеризация
    def _run(self, mode):
        if self.data is None:
            messagebox.showwarning("", "Загрузите данные."); return
        seeds = None
        if mode == 'kms':
            seeds = self._seed_dialog()
            if seeds is None: return

        def work():
            try:
                d = self.data
                if mode == 'km':
                    km = KMeans(n_clusters=N, n_init=10, random_state=42)
                    pred = match(km.fit_predict(d['Xss']), d['y'], N)
                    name = "K-Means"
                elif mode == 'gmm':
                    gmm = GaussianMixture(n_components=N, n_init=3, random_state=42)
                    pred = match(gmm.fit_predict(d['Xss']), d['y'], N)
                    name = "GMM"
                else:
                    if seeds == 'random':
                        rng = np.random.RandomState(42)
                        init = d['Xss'][rng.choice(len(d['Xss']), N, replace=False)]
                        name = "K-Means (случайные seed)"
                    else:
                        init = np.zeros((N, d['Xss'].shape[1]))
                        for i, idxs in enumerate(seeds):
                            init[i] = d['Xss'][idxs].mean(0) if idxs else \
                                      d['Xss'][[np.random.randint(len(d['Xss']))]].mean(0)
                        name = "K-Means (ручные seed)"
                    km = KMeans(n_clusters=N, init=init, n_init=1, random_state=42)
                    pred = match(km.fit_predict(d['Xss']), d['y'], N)

                self.pred = pred
                self.last_name = name
                p, r, f = get_metrics(d['y'], pred)
                txt = f"Метод: {name}\nТочность: {p:.4f}\nПолнота:  {r:.4f}\nF1-мера:  {f:.4f}"
                self.after(0, lambda: self.lbl_res.config(text=txt))
                self.after(0, lambda: self._draw_all(pred, name))
            except Exception as e:
                self.after(0, lambda: messagebox.showerror("Ошибка", str(e)))

        threading.Thread(target=work, daemon=True).start()

    def _draw_all(self, pred, name):
        d = self.data

        # Вкладка 3
        self.ax_res2.clear()
        self.ax_res2.imshow(colormap(pred, d['mask'], d['h'], d['w']))
        self.ax_res2.axis('off'); self.ax_res2.set_title(name)
        self.cv_res.draw()
        # Вкладка 4
        imgs   = [d['rgb'], gt_colormap(d['GT']), colormap(pred, d['mask'], d['h'], d['w'])]
        titles = ['Исходное RGB', 'Эталонная маска (GT)', f'Результат: {name}']
        for ax, img, t in zip(self.ax_cmp, imgs, titles):
            ax.clear(); ax.imshow(img); ax.axis('off'); ax.set_title(t, fontsize=9)
        self.fig_cmp.tight_layout(); self.cv_cmp.draw()
        # Вкладка 5 
        self._draw_cluster_spectra(pred)
        # Вкладка 6
        self._draw_cluster_vs_gt(pred)
        # Вкладка 8
        self._draw_heatmap(pred) 
        self.nb.select(2)

    # Графики
    def _draw_cluster_spectra(self, pred):
        d = self.data; X = d['Xraw']; y = d['y']
        bands = np.arange(X.shape[1])
        for i, ax in enumerate(self.ax_sp):
            ax.clear(); ax.axis('on')
            m = pred == i
            if m.sum() > 0:
                sp = X[m]; mean = sp.mean(0); std = sp.std(0)
                dom = CLASS_NAMES[np.bincount(y[m]).argmax()]
                pur = np.bincount(y[m]).max() / m.sum()
                ax.plot(bands, mean, color='steelblue', lw=1.5, label='Средний спектр')
                ax.fill_between(bands, mean-std, mean+std, alpha=0.3, color='steelblue', label='±СКО')
                ax.set_title(f'Кластер {i}  |  {dom} ({pur:.1%})', fontsize=8)
            else:
                ax.set_title(f'Кластер {i} (пустой)', fontsize=8)
            ax.set_xlabel('Канал', fontsize=7); ax.set_ylabel('Отражение', fontsize=7)
            ax.legend(fontsize=6); ax.grid(alpha=0.3); ax.tick_params(labelsize=6)
        self.fig_sp.suptitle('Средние спектры кластеров ± СКО', fontsize=11)
        self.fig_sp.tight_layout(); self.cv_sp.draw()

    def _draw_cluster_vs_gt(self, pred):
        d = self.data; X = d['Xraw']; y = d['y']
        bands = np.arange(X.shape[1])
        for i, ax in enumerate(self.ax_cg):
            ax.clear(); ax.axis('on')
            for arr, color, ls, lbl in [(pred==i,'steelblue','-','Кластер'),
                                         (y==i,   'tomato',   '--','Эталон')]:
                if arr.sum() > 0:
                    sp = X[arr]; mean = sp.mean(0); std = sp.std(0)
                    ax.plot(bands, mean, color=color, ls=ls, lw=1.5, label=lbl)
                    ax.fill_between(bands, mean-std, mean+std, alpha=0.2, color=color)
            m_cl = pred==i; m_gt = y==i
            if m_cl.sum() > 0 and m_gt.sum() > 0:
                v_cl = X[m_cl].mean(0); v_gt = X[m_gt].mean(0)
                cos = np.dot(v_cl,v_gt)/(np.linalg.norm(v_cl)*np.linalg.norm(v_gt)+1e-9)
                ax.text(0.97, 0.05, f'cos={cos:.3f}', transform=ax.transAxes,
                        ha='right', fontsize=7, color='steelblue', fontweight='bold')
            ax.set_title(CLASS_NAMES[i], fontsize=8)
            ax.set_xlabel('Канал', fontsize=7); ax.set_ylabel('Отражение', fontsize=7)
            ax.legend(fontsize=6); ax.grid(alpha=0.3); ax.tick_params(labelsize=6)
        self.fig_cg.suptitle('Кластер vs Эталонный класс', fontsize=11)
        self.fig_cg.tight_layout(); self.cv_cg.draw()

    def _draw_gt_spectra(self):
        d = self.data; X = d['Xraw']; y = d['y']
        bands = np.arange(X.shape[1])
        colors = plt.cm.tab10(np.linspace(0, 1, N))
        ax = self.ax_gts; ax.clear(); ax.axis('on')
        for c in range(N):
            m = y==c; sp = X[m]; mean = sp.mean(0); std = sp.std(0)
            ax.plot(bands, mean, color=colors[c], lw=1.5, label=f'{CLASS_NAMES[c]} ({m.sum()})')
            ax.fill_between(bands, mean-std, mean+std, alpha=0.10, color=colors[c])
        ax.set_xlabel('Канал (band)', fontsize=9)
        ax.set_ylabel('Нормализованное отражение', fontsize=9)
        ax.set_title('Спектральные профили 9 классов (Ground Truth)', fontsize=10)
        ax.legend(fontsize=7, ncol=3, loc='upper right'); ax.grid(alpha=0.3)
        self.fig_gts.tight_layout(); self.cv_gts.draw()

    def _draw_heatmap(self, pred):
        d = self.data; X = d['Xraw']; y = d['y']
        mat = np.zeros((N, N))
        for gt_c in range(N):
            m_gt = y==gt_c
            if m_gt.sum() == 0: continue
            v_gt = X[m_gt].mean(0)
            for cl in range(N):
                m_cl = pred==cl
                if m_cl.sum() == 0: continue
                v_cl = X[m_cl].mean(0)
                mat[gt_c,cl] = np.dot(v_gt,v_cl)/(np.linalg.norm(v_gt)*np.linalg.norm(v_cl)+1e-9)
        ax = self.ax_hm; ax.clear(); ax.axis('on')  
        self.fig_hm.clf()
        ax = self.fig_hm.add_subplot(111)
        self.ax_hm = ax
        im = ax.imshow(mat, vmin=0.7, vmax=1.0, cmap='RdYlGn', aspect='auto')
        ax.set_xticks(range(N))
        ax.set_xticklabels([f'Кл.{i}' for i in range(N)], rotation=45, ha='right', fontsize=8)
        ax.set_yticks(range(N)); ax.set_yticklabels(CLASS_NAMES, fontsize=8)
        ax.set_title('Сходство кластеров и GT классов\n(строка=GT, столбец=кластер)', fontsize=10)
        self.fig_hm.colorbar(im, ax=ax, fraction=0.046, pad=0.04)
        for r in range(N):
            for c in range(N):
                ax.text(c, r, f'{mat[r,c]:.2f}', ha='center', va='center',
                        fontsize=7, color='black' if mat[r,c]>0.85 else 'white')
        self.fig_hm.tight_layout(); self.cv_hm.draw()
   
    def _seed_dialog(self):
        dlg = tk.Toplevel(self)
        dlg.title("Seed-точки K-Means")
        dlg.resizable(False, False)
        dlg.grab_set()
        result = [None]
        mode = tk.StringVar(value="random")

        def toggle():
            s = 'normal' if mode.get()=='manual' else 'disabled'
            for e in entries: e.config(state=s)

        ttk.Radiobutton(dlg, text="Случайные seed-точки",
                        variable=mode, value="random", command=toggle).pack(anchor='w', padx=10, pady=5)
        ttk.Radiobutton(dlg, text="Ручные seed-точки",
                        variable=mode, value="manual", command=toggle).pack(anchor='w', padx=10)

        frame = ttk.LabelFrame(dlg, text="Индексы пикселей через запятую", padding=8)
        frame.pack(fill='x', padx=10, pady=8)
        n_pix = len(self.data['Xss'])
        ttk.Label(frame, text=f"Допустимо: 0 – {n_pix-1}", foreground='gray').pack(anchor='w')

        entries = []
        for cn in CLASS_NAMES:
            row = ttk.Frame(frame); row.pack(fill='x', pady=1)
            ttk.Label(row, text=cn+':', width=18).pack(side='left')
            e = ttk.Entry(row, width=32, state='disabled'); e.pack(side='left')
            entries.append(e)

        def ok():
            if mode.get()=='random':
                result[0]='random'; dlg.destroy(); return
            seeds=[]
            for i,e in enumerate(entries):
                txt=e.get().strip()
                if not txt:
                    seeds.append([np.random.randint(n_pix)]); continue
                try:
                    idxs=[int(x) for x in txt.split(',') if x.strip()]
                    for idx in idxs:
                        if not (0<=idx<n_pix):
                            messagebox.showerror("Ошибка",f"Индекс {idx} вне диапазона"); return
                    seeds.append(idxs)
                except ValueError:
                    messagebox.showerror("Ошибка",f"Неверный формат: {CLASS_NAMES[i]}"); return
            result[0]=seeds; dlg.destroy()

        ttk.Button(dlg, text="Запустить", command=ok).pack(pady=8)
        dlg.wait_window()
        return result[0]


if __name__ == '__main__':
    App().mainloop()
@echo off
chcp 65001 > nul
cd /d "%~dp0"

echo Checking VcXsrv...
tasklist /FI "IMAGENAME eq vcxsrv.exe" 2>NUL | find /I "vcxsrv.exe" > NUL
if errorlevel 1 (
    echo Starting VcXsrv...
    start "" "C:\Program Files\VcXsrv\vcxsrv.exe" :0 -multiwindow -clipboard -wgl -ac
    timeout /t 2 /nobreak > nul
) else (
    echo VcXsrv already running, skipping...
)

echo Launching HSI App...
docker run -it ^
  -e DISPLAY=host.docker.internal:0 ^
  -v "%cd%:/app" ^
  hsi-app

pause

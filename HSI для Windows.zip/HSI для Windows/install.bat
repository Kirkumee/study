@echo off
chcp 65001 > nul
cd /d "%~dp0"
echo Building Docker
docker build -t hsi-app .
echo.
echo Done! Now open run.bat
pause

import numpy as np
from PIL import Image as PILImage

_STRIPE = 183
_CENTER_START = 8
_CENTER_END = 18


def _center_per_stripe(band):
    h = band.shape[0]
    centers = []
    for i in range(h // _STRIPE + 1):
        r0, r1 = i * _STRIPE, min((i + 1) * _STRIPE, h)
        ls, rs = [], []
        for r in range(r0, r1):
            nz = np.where(band[r] > 50)[0]
            if len(nz) > 5:
                ls.append(float(nz[0]))
                rs.append(float(nz[-1]))
        if ls:
            centers.append((float(np.median(ls)) + float(np.median(rs))) / 2.0)
        else:
            centers.append(np.nan)
    return np.array(centers)


def _compute_half_jump(centers):
    n = len(centers)
    jumps = []
    for i in range(0, n - 1, 2):
        if not np.isnan(centers[i]) and not np.isnan(centers[i + 1]):
            j = centers[i + 1] - centers[i]
            if abs(j) < 30:
                jumps.append(j)
    if not jumps:
        return 0.0
    return float(np.median(jumps)) / 2.0


def _stripe_weight(i, n):
    if i < _CENTER_START:
        return i / _CENTER_START
    return 1.0


def _apply(band, half_jump):
    h, w = band.shape
    out = band.copy()
    xs = np.arange(w, dtype=np.float32)
    n = h // _STRIPE + 1
    for i in range(n):
        r0, r1 = i * _STRIPE, min((i + 1) * _STRIPE, h)
        weight = _stripe_weight(i, n)
        shift = (+half_jump if i % 2 == 0 else -half_jump) * weight
        if abs(shift) < 0.1:
            continue
        src = np.clip(xs - shift, 0, w - 1)
        x0 = np.floor(src).astype(np.int32)
        x1 = np.minimum(x0 + 1, w - 1)
        t = (src - x0).astype(np.float32)
        for r in range(r0, r1):
            out[r] = band[r][x0] * (1 - t) + band[r][x1] * t
    return out


def destripe_and_squeeze(img, w, h, c, sensitivity=2.0):
    if isinstance(img, np.ndarray):
        arr = img.astype(np.float32)
    else:
        arr = np.array(img, dtype=np.float32)
    if arr.ndim == 2:
        arr = arr[:, :, np.newaxis]

    out_channels = []
    for ch in range(arr.shape[2]):
        band = arr[:, :, ch].copy()
        centers = _center_per_stripe(band)
        if np.sum(~np.isnan(centers)) < 4:
            out_channels.append(band)
            continue
        half_jump = _compute_half_jump(centers)
        if abs(half_jump) < 0.5:
            out_channels.append(band)
            continue
        out_channels.append(_apply(band, half_jump))

    return np.stack(out_channels, axis=2).clip(0, 255).astype(np.uint8)


def destripe_fourier(img, w, h, c, sensitivity=2.0):
    return destripe_and_squeeze(img, w, h, c)

def destripe_fourier_aggressive(img, w, h, c):
    return destripe_and_squeeze(img, w, h, c)

def destripe_moment_matching_rows(img, window=50):
    arr = np.array(img) if not isinstance(img, np.ndarray) else img
    h, w = arr.shape[:2]
    c = 1 if arr.ndim == 2 else arr.shape[2]
    return destripe_and_squeeze(img, w, h, c)
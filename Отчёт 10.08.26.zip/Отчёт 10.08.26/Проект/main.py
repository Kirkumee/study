import tkinter as tk
from tkinter import ttk, filedialog, messagebox
import threading
import numpy as np
import scipy.io as sio
from sklearn.decomposition import IncrementalPCA
from sklearn.cluster import KMeans
from sklearn.mixture import GaussianMixture
from sklearn.metrics import f1_score, precision_score, recall_score
from scipy.optimize import linear_sum_assignment
from scipy.ndimage import uniform_filter
from scipy.spatial.distance import cdist
import matplotlib.pyplot as plt
from matplotlib.backends.backend_tkagg import FigureCanvasTkAgg
import spectral
import warnings
warnings.filterwarnings('ignore')

CLASS_NAMES = ['Асфальт', 'Луга', 'Гравий', 'Деревья', 'Металлические листы',
               'Голая почва', 'Битум', 'Кирпичная кладка', 'Тени']
N = 9
COL_BG, COL_PANEL, COL_BORDER = '#f2f2f2', '#ffffff', '#d9d9d9'
COL_TEXT, COL_MUTED, COL_ACCENT = '#2b2b2b', '#808080', '#4a76a8'
COL_SEL = '#e6e6e6'
FONT_BASE, FONT_BOLD = ('Segoe UI', 10), ('Segoe UI', 10, 'bold')
FONT_TITLE = ('Segoe UI', 12, 'bold')
VIEWS = [('src', 'Исходное изображение'), ('gt', 'Эталонная маска'), ('res', 'Результат'),
         ('cmp', 'GT + Результат'), ('sp', 'Спектры кластеров'), ('cg', 'Кластер + Эталон'),
         ('gts', 'Спектры GT'), ('hm', 'Карта сходства')]

def match(y_pred, y_true, n):
    cost = np.zeros((n, n))
    for i in range(n):
        for j in range(n):
            cost[i, j] = -np.sum((y_pred == i) & (y_true == j))
    r, c = linear_sum_assignment(cost)
    m = dict(zip(r, c))
    return np.array([m[l] for l in y_pred])

def prepare(hsi_path, gt_path):
    HSI = sio.loadmat(hsi_path)['paviaU']
    GT = sio.loadmat(gt_path)['paviaU_gt']
    h, w = GT.shape
    flat = HSI.reshape(-1, HSI.shape[2])
    pca = IncrementalPCA(n_components=20)
    for b in np.array_split(flat, 256):
        pca.partial_fit(b)
    X3 = pca.transform(flat).reshape(h, w, 20)
    sm = np.zeros_like(X3)
    for ch in range(20):
        sm[:, :, ch] = uniform_filter(X3[:, :, ch], size=5)
    Xss = np.concatenate([X3, sm], axis=2).reshape(-1, 40)
    mask = GT.flatten() > 0
    Xraw = HSI.reshape(-1, HSI.shape[2])[mask].astype(float)
    Xraw = (Xraw - Xraw.min()) / (Xraw.max() - Xraw.min() + 1e-8)
    rgb = HSI[:, :, [30, 20, 10]].astype(float)
    rgb = (rgb - rgb.min()) / (rgb.max() - rgb.min())
    return {'Xss': Xss[mask], 'Xraw': Xraw, 'y': GT.flatten()[mask] - 1,
            'mask': mask, 'h': h, 'w': w, 'GT': GT, 'rgb': rgb}

def get_metrics(y_true, y_pred):
    p = precision_score(y_true, y_pred, average='weighted', zero_division=0)
    r = recall_score(y_true, y_pred, average='weighted', zero_division=0)
    f = f1_score(y_true, y_pred, average='weighted', zero_division=0)
    return p, r, f

def colormap(pred, mask, h, w):
    spy = np.array(spectral.spy_colors) / 255.0
    img = np.zeros((h * w, 3))
    img[mask] = spy[pred + 1]
    return img.reshape(h, w, 3)

def gt_colormap(GT):
    spy = np.array(spectral.spy_colors) / 255.0
    h, w = GT.shape
    img = np.zeros((h * w, 3))
    for c in range(1, 10):
        img[GT.flatten() == c] = spy[c]
    return img.reshape(h, w, 3)

def _normalize01(D):
    mn, mx = D.min(), D.max()
    return (D - mn) / (mx - mn + 1e-12)

def spectral_distance(X, C, metric):
    if metric == 'euclid':
        return cdist(X, C, 'euclidean')
    if metric == 'corr':
        return cdist(X, C, 'correlation')
    if metric == 'sam':
        cos = 1 - cdist(X, C, 'cosine')
        return np.arccos(np.clip(cos, -1, 1))
    raise ValueError(metric)

def spectral_cluster(X, n_clusters, metric='euclid', weights=(1, 1, 1), max_iter=30, seed=None, progress_cb=None):
    rng = np.random.default_rng(seed)
    idx = rng.choice(len(X), n_clusters, replace=False)
    C = X[idx].astype(float).copy()
    labels = np.full(len(X), -1)
    for it in range(max_iter):
        if metric == 'combo':
            we, ws, wc = weights
            total = we + ws + wc
            if total <= 0:
                we, ws, wc, total = 1, 1, 1, 3
            De = _normalize01(spectral_distance(X, C, 'euclid'))
            Ds = _normalize01(spectral_distance(X, C, 'sam'))
            Dc = _normalize01(spectral_distance(X, C, 'corr'))
            D = (we * De + ws * Ds + wc * Dc) / total
        else:
            D = spectral_distance(X, C, metric)
        new_labels = D.argmin(axis=1)
        changed = int(np.sum(new_labels != labels))
        labels = new_labels
        for k in range(n_clusters):
            pts = X[labels == k]
            if len(pts) > 0:
                C[k] = pts.mean(axis=0)
        if progress_cb:
            progress_cb(it + 1, max_iter)
        if changed == 0 and it > 0:
            break
    return labels

class App(tk.Tk):
    def __init__(self):
        super().__init__()
        self.title("Кластеризация изображений")
        self.configure(bg=COL_BG)
        self.minsize(1150, 700)
        self._maximize()
        self.hsi = self.gt_path = self.data = self.pred = self.last_name = None
        self._busy = False
        self.view_frames, self.nav_buttons, self.current_view = {}, {}, None
        self._init_style()
        self._build()

    def _maximize(self):
        try:
            self.state('zoomed')
        except tk.TclError:
            try:
                self.attributes('-zoomed', True)
            except tk.TclError:
                sw, sh = self.winfo_screenwidth(), self.winfo_screenheight()
                self.geometry(f"{sw}x{sh}+0+0")

    def _init_style(self):
        style = ttk.Style(self)
        try:
            style.theme_use('clam')
        except tk.TclError:
            pass
        cfg = {
            '.': dict(font=FONT_BASE, background=COL_BG, foreground=COL_TEXT),
            'TFrame': dict(background=COL_BG),
            'Panel.TFrame': dict(background=COL_PANEL),
            'TLabel': dict(background=COL_BG, foreground=COL_TEXT),
            'Panel.TLabel': dict(background=COL_PANEL, foreground=COL_TEXT),
            'Muted.TLabel': dict(background=COL_PANEL, foreground=COL_MUTED, font=('Segoe UI', 8)),
            'Title.TLabel': dict(background=COL_BG, foreground=COL_TEXT, font=FONT_TITLE),
            'Metric.TLabel': dict(background=COL_PANEL, foreground=COL_MUTED, font=('Segoe UI', 9)),
            'MetricVal.TLabel': dict(background=COL_PANEL, foreground=COL_TEXT, font=FONT_BOLD),
            'Accent.TButton': dict(font=FONT_BASE, padding=(10, 7), background=COL_ACCENT, foreground='white', borderwidth=0),
            'Plain.TButton': dict(font=FONT_BASE, padding=(10, 7), background=COL_PANEL, foreground=COL_TEXT, borderwidth=1),
            'Nav.TButton': dict(font=FONT_BASE, padding=(12, 8), anchor='w', background=COL_BG, foreground=COL_TEXT, borderwidth=0),
            'NavActive.TButton': dict(font=FONT_BOLD, padding=(12, 8), anchor='w', background=COL_SEL, foreground=COL_TEXT, borderwidth=0),
            'MetricActive.TButton': dict(font=FONT_BOLD, padding=(10, 7), background=COL_SEL, foreground=COL_TEXT, borderwidth=1),
            'Horizontal.TScale': dict(background=COL_PANEL, troughcolor=COL_SEL),
            'Accent.Horizontal.TProgressbar': dict(background=COL_ACCENT, troughcolor=COL_SEL),
        }
        for name, opts in cfg.items():
            style.configure(name, **opts)
        style.map('Accent.TButton', background=[('active', '#3d6491'), ('disabled', '#b7c4d3')])
        style.map('Plain.TButton', background=[('active', COL_SEL)])
        style.map('MetricActive.TButton', background=[('active', COL_SEL)])
        style.map('Nav.TButton', background=[('active', COL_SEL)])

    def _build(self):
        top = ttk.Frame(self)
        top.pack(side='top', fill='x')
        ttk.Label(top, text="Кластеризация изображений", style='Title.TLabel').pack(anchor='w', padx=16, pady=12)
        ttk.Separator(self).pack(fill='x')

        body = ttk.Frame(self)
        body.pack(side='top', fill='both', expand=True)
        sidebar = ttk.Frame(body, style='Panel.TFrame', width=240)
        sidebar.pack(side='left', fill='y')
        sidebar.pack_propagate(False)

        self.btn_hsi = ttk.Button(sidebar, text="Открыть HSI…", style='Plain.TButton', command=self._open_hsi)
        self.btn_hsi.pack(fill='x', padx=14, pady=(16, 3))
        self.lbl_hsi = ttk.Label(sidebar, text="", style='Muted.TLabel', wraplength=210)
        self.lbl_hsi.pack(anchor='w', padx=16)
        self.btn_gt = ttk.Button(sidebar, text="Открыть GT…", style='Plain.TButton', command=self._open_gt)
        self.btn_gt.pack(fill='x', padx=14, pady=(8, 3))
        self.lbl_gt = ttk.Label(sidebar, text="", style='Muted.TLabel', wraplength=210)
        self.lbl_gt.pack(anchor='w', padx=16)
        self.btn_prepare = ttk.Button(sidebar, text="Загрузить данные", style='Accent.TButton', command=self._prepare)
        self.btn_prepare.pack(fill='x', padx=14, pady=(10, 0))
        ttk.Separator(sidebar).pack(fill='x', padx=14, pady=14)

        self.btn_km = ttk.Button(sidebar, text="K-Means", style='Plain.TButton', command=lambda: self._run('km'))
        self.btn_km.pack(fill='x', padx=14, pady=3)
        self.btn_gmm = ttk.Button(sidebar, text="GMM", style='Plain.TButton', command=lambda: self._run('gmm'))
        self.btn_gmm.pack(fill='x', padx=14, pady=3)
        self.btn_kms = ttk.Button(sidebar, text="K-Means + seed…", style='Plain.TButton', command=lambda: self._run('kms'))
        self.btn_kms.pack(fill='x', padx=14, pady=3)
        self._cluster_buttons = [self.btn_km, self.btn_gmm, self.btn_kms]
        ttk.Separator(sidebar).pack(fill='x', padx=14, pady=14)

        ttk.Label(sidebar, text="Метрика расстояния", style='Muted.TLabel').pack(anchor='w', padx=14)
        self.metric_var = tk.StringVar(value='euclid')
        self.metric_buttons = {}
        for val, txt in [('euclid', 'Евклидово расстояние'), ('sam', 'Спектральный угол (SAM)'),
                          ('corr', 'Корреляция'), ('combo', 'Комбо (с весами)')]:
            b = ttk.Button(sidebar, text=txt, style='Plain.TButton', command=lambda v=val: self._set_metric(v))
            b.pack(fill='x', padx=14, pady=2)
            self.metric_buttons[val] = b

        weights_frame = ttk.Frame(sidebar, style='Panel.TFrame')
        weights_frame.pack(fill='x', padx=14, pady=(4, 0))
        self.w_euclid, self.w_sam, self.w_corr = tk.DoubleVar(value=1.0), tk.DoubleVar(value=1.0), tk.DoubleVar(value=1.0)
        self.weight_scales = []
        for lbl, var in [("Евклид", self.w_euclid), ("SAM", self.w_sam), ("Корреляция", self.w_corr)]:
            row = ttk.Frame(weights_frame, style='Panel.TFrame')
            row.pack(fill='x', pady=2)
            ttk.Label(row, text=lbl, style='Metric.TLabel', width=9).pack(side='left')
            val_lbl = ttk.Label(row, text=f"{var.get():.2f}", style='MetricVal.TLabel', width=4, anchor='e')
            val_lbl.pack(side='right')
            sc = ttk.Scale(row, from_=0, to=1, orient='horizontal', variable=var,
                            command=lambda v, l=val_lbl: l.config(text=f"{float(v):.2f}"))
            sc.pack(side='left', fill='x', expand=True, padx=(4, 6))
            self.weight_scales.append(sc)

        self.btn_spectral = ttk.Button(sidebar, text="Запустить кластеризацию", style='Plain.TButton', command=self._run_spectral)
        self.btn_spectral.pack(fill='x', padx=14, pady=(8, 3))
        self._cluster_buttons.append(self.btn_spectral)
        self._cluster_buttons.extend(self.metric_buttons.values())
        self._toggle_weights()
        ttk.Separator(sidebar).pack(fill='x', padx=14, pady=14)

        results = ttk.Frame(sidebar, style='Panel.TFrame')
        results.pack(fill='x', padx=14)
        self.lbl_method_val = self._metric_row(results, "Метод")
        self.lbl_prec_val = self._metric_row(results, "Точность")
        self.lbl_rec_val = self._metric_row(results, "Полнота")
        self.lbl_f1_val = self._metric_row(results, "F1-мера")

        self.progress_lbl = ttk.Label(results, text="", style='Muted.TLabel')
        self.progress_lbl.pack(anchor='w', pady=(8, 2))
        self.progress_bar = ttk.Progressbar(results, mode='determinate', maximum=100, style='Accent.Horizontal.TProgressbar')
        self.progress_bar.pack(fill='x')

        ttk.Separator(body, orient='vertical').pack(side='left', fill='y')

        nav = ttk.Frame(body, width=180)
        nav.pack(side='left', fill='y')
        nav.pack_propagate(False)
        for key, title in VIEWS:
            b = ttk.Button(nav, text=title, style='Nav.TButton', command=lambda k=key: self._show_view(k))
            b.pack(fill='x', padx=0, pady=0)
            self.nav_buttons[key] = b

        ttk.Separator(body, orient='vertical').pack(side='left', fill='y')

        self.content = ttk.Frame(body)
        self.content.pack(side='right', fill='both', expand=True, padx=10, pady=10)
        self.content.grid_rowconfigure(0, weight=1)
        self.content.grid_columnconfigure(0, weight=1)
        self.fig_src, self.ax_src, self.cv_src = self._make_tab('src')
        self.fig_gt2, self.ax_gt2, self.cv_gt2 = self._make_tab('gt')
        self.fig_res, self.ax_res2, self.cv_res = self._make_tab('res')
        self.fig_cmp, self.ax_cmp, self.cv_cmp = self._make_grid_tab('cmp', 1, 3)
        self.fig_sp, self.ax_sp, self.cv_sp = self._make_grid_tab('sp', 3, 3)
        self.fig_cg, self.ax_cg, self.cv_cg = self._make_grid_tab('cg', 3, 3)
        self.fig_gts, self.ax_gts, self.cv_gts = self._make_tab('gts')
        self.fig_hm, self.ax_hm, self.cv_hm = self._make_tab('hm')
        self._show_view('src')

    def _metric_row(self, parent, label):
        row = ttk.Frame(parent, style='Panel.TFrame')
        row.pack(fill='x', pady=2)
        ttk.Label(row, text=label, style='Metric.TLabel').pack(side='left')
        val = ttk.Label(row, text="—", style='MetricVal.TLabel')
        val.pack(side='right')
        return val

    def _set_busy(self, busy):
        self._busy = busy
        state = 'disabled' if busy else 'normal'
        for b in [self.btn_hsi, self.btn_gt, self.btn_prepare] + self._cluster_buttons:
            b.config(state=state)

    def _set_metric(self, val):
        self.metric_var.set(val)
        for k, b in self.metric_buttons.items():
            b.config(style='MetricActive.TButton' if k == val else 'Plain.TButton')
        self._toggle_weights()

    def _toggle_weights(self):
        state = 'normal' if self.metric_var.get() == 'combo' else 'disabled'
        for sc in self.weight_scales:
            sc.config(state=state)

    def _update_progress(self, it, total):
        pct = int(it / total * 100)
        self.progress_bar['value'] = pct
        self.progress_lbl.config(text=f"Кластеризация: {pct}% (итерация {it}/{total})")

    def _reset_progress(self):
        self.progress_bar['value'] = 0
        self.progress_lbl.config(text="")

    def _run_spectral(self):
        if self._busy:
            return
        if self.data is None:
            messagebox.showwarning("Нет данных", "Сначала загрузите данные.")
            return
        metric = self.metric_var.get()
        weights = (self.w_euclid.get(), self.w_sam.get(), self.w_corr.get())
        names = {'euclid': 'Евклидово расстояние', 'sam': 'Спектральный угол (SAM)', 'corr': 'Корреляция'}

        def progress_cb(it, total):
            self.after(0, lambda: self._update_progress(it, total))

        def work():
            try:
                d = self.data
                labels = spectral_cluster(d['Xraw'], N, metric=metric, weights=weights, max_iter=30, progress_cb=progress_cb)
                pred = match(labels, d['y'], N)
                if metric == 'combo':
                    we, ws, wc = weights
                    name = f"Комбинированная (Евкл={we:.2f}, SAM={ws:.2f}, Корр={wc:.2f})"
                else:
                    name = names[metric]
                self.pred, self.last_name = pred, name
                p, r, f = get_metrics(d['y'], pred)
                self.after(0, lambda: self._update_metrics(name, p, r, f))
                self.after(0, lambda: self._draw_all(pred, name))
            except Exception as e:
                self.after(0, lambda: messagebox.showerror("Ошибка", str(e)))
            finally:
                self.after(0, self._reset_progress)
                self.after(0, lambda: self._set_busy(False))
        self._set_busy(True)
        self.progress_lbl.config(text="Кластеризация: 0%")
        self.progress_bar['value'] = 0
        threading.Thread(target=work, daemon=True).start()

    def _show_view(self, key):
        self.view_frames[key].tkraise()
        for k, b in self.nav_buttons.items():
            b.config(style='NavActive.TButton' if k == key else 'Nav.TButton')
        self.current_view = key

    def _make_tab(self, key):
        f = ttk.Frame(self.content)
        f.grid(row=0, column=0, sticky='nsew')
        self.view_frames[key] = f
        fig = plt.Figure(tight_layout=True)
        ax = fig.add_subplot(111)
        ax.axis('off')
        cv = FigureCanvasTkAgg(fig, master=f)
        cv.get_tk_widget().pack(fill='both', expand=True)
        return fig, ax, cv

    def _make_grid_tab(self, key, rows, cols):
        f = ttk.Frame(self.content)
        f.grid(row=0, column=0, sticky='nsew')
        self.view_frames[key] = f
        fig = plt.Figure(tight_layout=True)
        axes = [fig.add_subplot(rows, cols, i + 1) for i in range(rows * cols)]
        for ax in axes:
            ax.axis('off')
        cv = FigureCanvasTkAgg(fig, master=f)
        cv.get_tk_widget().pack(fill='both', expand=True)
        return fig, axes, cv

    def _open_hsi(self):
        p = filedialog.askopenfilename(filetypes=[("MAT", "*.mat")])
        if p:
            self.hsi = p
            self.lbl_hsi.config(text=p.split('/')[-1])

    def _open_gt(self):
        p = filedialog.askopenfilename(filetypes=[("MAT", "*.mat")])
        if p:
            self.gt_path = p
            self.lbl_gt.config(text=p.split('/')[-1])

    def _prepare(self):
        if self._busy:
            return
        if not self.hsi or not self.gt_path:
            messagebox.showwarning("Не хватает файлов", "Выберите оба файла (HSI и GT).")
            return

        def work():
            try:
                self.data = prepare(self.hsi, self.gt_path)
                self.after(0, self._draw_src_gt)
            except Exception as e:
                self.after(0, lambda: messagebox.showerror("Ошибка", str(e)))
            finally:
                self.after(0, lambda: self._set_busy(False))
        self._set_busy(True)
        threading.Thread(target=work, daemon=True).start()

    def _draw_src_gt(self):
        d = self.data
        self.ax_src.clear(); self.ax_src.imshow(d['rgb']); self.ax_src.axis('off'); self.cv_src.draw()
        self.ax_gt2.clear(); self.ax_gt2.imshow(gt_colormap(d['GT'])); self.ax_gt2.axis('off'); self.cv_gt2.draw()
        self._draw_gt_spectra()
        self._show_view('src')

    def _run(self, mode):
        if self._busy:
            return
        if self.data is None:
            messagebox.showwarning("Нет данных", "Сначала загрузите данные.")
            return
        seeds = None
        if mode == 'kms':
            seeds = self._seed_dialog()
            if seeds is None:
                return

        def work():
            try:
                d = self.data
                if mode == 'km':
                    km = KMeans(n_clusters=N, n_init=10, random_state=42)
                    pred = match(km.fit_predict(d['Xss']), d['y'], N)
                    name = "K-Means"
                elif mode == 'gmm':
                    gmm = GaussianMixture(n_components=N, n_init=3, random_state=42)
                    pred = match(gmm.fit_predict(d['Xss']), d['y'], N)
                    name = "GMM"
                else:
                    if seeds == 'random':
                        rng = np.random.default_rng()
                        idxs = rng.choice(len(d['Xss']), N, replace=False)
                        init = d['Xss'][idxs]
                        name = "K-Means (случайные seed)"
                        seed_info = ", ".join(str(i) for i in idxs.tolist())
                    else:
                        init = np.zeros((N, d['Xss'].shape[1]))
                        for i, idxs in enumerate(seeds):
                            init[i] = d['Xss'][idxs].mean(0) if idxs else d['Xss'][[np.random.randint(len(d['Xss']))]].mean(0)
                        name = "K-Means (ручные seed)"
                        seed_info = None
                    km = KMeans(n_clusters=N, init=init, n_init=1, random_state=42)
                    pred = match(km.fit_predict(d['Xss']), d['y'], N)
                    if seed_info:
                        self.after(0, lambda: messagebox.showinfo("Случайные seed-точки", f"Индексы пикселей:\n{seed_info}"))
                self.pred, self.last_name = pred, name
                p, r, f = get_metrics(d['y'], pred)
                self.after(0, lambda: self._update_metrics(name, p, r, f))
                self.after(0, lambda: self._draw_all(pred, name))
            except Exception as e:
                self.after(0, lambda: messagebox.showerror("Ошибка", str(e)))
            finally:
                self.after(0, lambda: self._set_busy(False))
        self._set_busy(True)
        threading.Thread(target=work, daemon=True).start()

    def _update_metrics(self, name, p, r, f):
        self.lbl_method_val.config(text=name)
        self.lbl_prec_val.config(text=f"{p:.4f}")
        self.lbl_rec_val.config(text=f"{r:.4f}")
        self.lbl_f1_val.config(text=f"{f:.4f}")

    def _draw_all(self, pred, name):
        d = self.data
        self.ax_res2.clear(); self.ax_res2.imshow(colormap(pred, d['mask'], d['h'], d['w'])); self.ax_res2.axis('off'); self.cv_res.draw()
        imgs = [d['rgb'], gt_colormap(d['GT']), colormap(pred, d['mask'], d['h'], d['w'])]
        titles = ['Исходное RGB', 'Эталонная маска', f'Результат: {name}']
        for ax, img, t in zip(self.ax_cmp, imgs, titles):
            ax.clear(); ax.imshow(img); ax.axis('off'); ax.set_title(t, fontsize=9)
        self.fig_cmp.tight_layout(); self.cv_cmp.draw()
        self._draw_cluster_spectra(pred)
        self._draw_cluster_vs_gt(pred)
        self._draw_heatmap(pred)
        self._show_view('res')

    def _draw_cluster_spectra(self, pred):
        d = self.data
        X, y = d['Xraw'], d['y']
        bands = np.arange(X.shape[1])
        for i, ax in enumerate(self.ax_sp):
            ax.clear(); ax.axis('on')
            m = pred == i
            if m.sum() > 0:
                sp = X[m]
                mean, std = sp.mean(0), sp.std(0)
                dom = CLASS_NAMES[np.bincount(y[m]).argmax()]
                pur = np.bincount(y[m]).max() / m.sum()
                ax.plot(bands, mean, color='steelblue', lw=1.5, label='Средний спектр')
                ax.fill_between(bands, mean - std, mean + std, alpha=0.3, color='steelblue', label='±СКО')
                ax.set_title(f'Кластер {i}  |  {dom} ({pur:.1%})', fontsize=8)
            else:
                ax.set_title(f'Кластер {i} (пустой)', fontsize=8)
            ax.set_xlabel('Канал', fontsize=7); ax.set_ylabel('Отражение', fontsize=7)
            ax.legend(fontsize=6); ax.grid(alpha=0.3); ax.tick_params(labelsize=6)
        self.fig_sp.tight_layout(); self.cv_sp.draw()

    def _draw_cluster_vs_gt(self, pred):
        d = self.data
        X, y = d['Xraw'], d['y']
        bands = np.arange(X.shape[1])
        for i, ax in enumerate(self.ax_cg):
            ax.clear(); ax.axis('on')
            for arr, color, ls, lbl in [(pred == i, 'steelblue', '-', 'Кластер'), (y == i, 'tomato', '--', 'Эталон')]:
                if arr.sum() > 0:
                    sp = X[arr]
                    mean, std = sp.mean(0), sp.std(0)
                    ax.plot(bands, mean, color=color, ls=ls, lw=1.5, label=lbl)
                    ax.fill_between(bands, mean - std, mean + std, alpha=0.2, color=color)
            m_cl, m_gt = pred == i, y == i
            if m_cl.sum() > 0 and m_gt.sum() > 0:
                v_cl, v_gt = X[m_cl].mean(0), X[m_gt].mean(0)
                cos = np.dot(v_cl, v_gt) / (np.linalg.norm(v_cl) * np.linalg.norm(v_gt) + 1e-9)
                ax.text(0.97, 0.05, f'cos={cos:.3f}', transform=ax.transAxes, ha='right', fontsize=7, color='steelblue', fontweight='bold')
            ax.set_title(CLASS_NAMES[i], fontsize=8)
            ax.set_xlabel('Канал', fontsize=7); ax.set_ylabel('Отражение', fontsize=7)
            ax.legend(fontsize=6); ax.grid(alpha=0.3); ax.tick_params(labelsize=6)
        self.fig_cg.tight_layout(); self.cv_cg.draw()

    def _draw_gt_spectra(self):
        d = self.data
        X, y = d['Xraw'], d['y']
        bands = np.arange(X.shape[1])
        colors = plt.cm.tab10(np.linspace(0, 1, N))
        ax = self.ax_gts
        ax.clear(); ax.axis('on')
        for c in range(N):
            m = y == c
            sp = X[m]
            mean, std = sp.mean(0), sp.std(0)
            ax.plot(bands, mean, color=colors[c], lw=1.5, label=f'{CLASS_NAMES[c]} ({m.sum()})')
            ax.fill_between(bands, mean - std, mean + std, alpha=0.10, color=colors[c])
        ax.set_xlabel('Канал (band)', fontsize=9); ax.set_ylabel('Нормализованное отражение', fontsize=9)
        ax.legend(fontsize=7, ncol=3, loc='upper right'); ax.grid(alpha=0.3)
        self.fig_gts.tight_layout(); self.cv_gts.draw()

    def _draw_heatmap(self, pred):
        d = self.data
        X, y = d['Xraw'], d['y']
        mat = np.zeros((N, N))
        for gt_c in range(N):
            m_gt = y == gt_c
            if m_gt.sum() == 0:
                continue
            v_gt = X[m_gt].mean(0)
            for cl in range(N):
                m_cl = pred == cl
                if m_cl.sum() == 0:
                    continue
                v_cl = X[m_cl].mean(0)
                mat[gt_c, cl] = np.dot(v_gt, v_cl) / (np.linalg.norm(v_gt) * np.linalg.norm(v_cl) + 1e-9)
        self.fig_hm.clf()
        ax = self.fig_hm.add_subplot(111)
        self.ax_hm = ax
        im = ax.imshow(mat, vmin=0.7, vmax=1.0, cmap='RdYlGn', aspect='auto')
        ax.set_xticks(range(N)); ax.set_xticklabels([f'Кл.{i}' for i in range(N)], rotation=45, ha='right', fontsize=8)
        ax.set_yticks(range(N)); ax.set_yticklabels(CLASS_NAMES, fontsize=8)
        self.fig_hm.colorbar(im, ax=ax, fraction=0.046, pad=0.04)
        for r in range(N):
            for c in range(N):
                ax.text(c, r, f'{mat[r, c]:.2f}', ha='center', va='center', fontsize=7, color='black' if mat[r, c] > 0.85 else 'white')
        self.fig_hm.tight_layout(); self.cv_hm.draw()

    def _seed_dialog(self):
        dlg = tk.Toplevel(self)
        dlg.title("Seed-точки K-Means")
        dlg.configure(bg=COL_PANEL)
        dlg.resizable(False, False)
        dlg.transient(self)
        dlg.grab_set()
        result = [None]
        mode = tk.StringVar(value="random")

        def toggle():
            s = 'normal' if mode.get() == 'manual' else 'disabled'
            for e in entries:
                e.config(state=s)

        ttk.Radiobutton(dlg, text="Случайные seed-точки", variable=mode, value="random", command=toggle).pack(anchor='w', padx=16, pady=(14, 2))
        ttk.Radiobutton(dlg, text="Ручные seed-точки", variable=mode, value="manual", command=toggle).pack(anchor='w', padx=16)
        frame = ttk.LabelFrame(dlg, text="Индексы пикселей через запятую", padding=8)
        frame.pack(fill='x', padx=14, pady=10)
        n_pix = len(self.data['Xss'])
        ttk.Label(frame, text=f"Допустимо: 0 – {n_pix - 1}", foreground=COL_MUTED).pack(anchor='w')

        entries = []
        for cn in CLASS_NAMES:
            row = ttk.Frame(frame)
            row.pack(fill='x', pady=1)
            ttk.Label(row, text=cn + ':', width=18).pack(side='left')
            e = ttk.Entry(row, width=32, state='disabled')
            e.pack(side='left')
            entries.append(e)

        def ok():
            if mode.get() == 'random':
                result[0] = 'random'; dlg.destroy(); return
            seeds = []
            for i, e in enumerate(entries):
                txt = e.get().strip()
                if not txt:
                    seeds.append([np.random.randint(n_pix)]); continue
                try:
                    idxs = [int(x) for x in txt.split(',') if x.strip()]
                    for idx in idxs:
                        if not (0 <= idx < n_pix):
                            messagebox.showerror("Ошибка", f"Индекс {idx} вне диапазона"); return
                    seeds.append(idxs)
                except ValueError:
                    messagebox.showerror("Ошибка", f"Неверный формат: {CLASS_NAMES[i]}"); return
            result[0] = seeds
            dlg.destroy()

        btns = ttk.Frame(dlg, style='Panel.TFrame')
        btns.pack(fill='x', padx=14, pady=(0, 14))
        ttk.Button(btns, text="Отмена", style='Plain.TButton', command=dlg.destroy).pack(side='right', padx=(6, 0))
        ttk.Button(btns, text="Запустить", style='Accent.TButton', command=ok).pack(side='right')
        dlg.wait_window()
        return result[0]

if __name__ == '__main__':
    App().mainloop()
import numpy as np
from scipy.optimize import curve_fit
from PIL import Image as PILImage

_STRIPE = 183
_STD_THRESHOLD = 5.0


def _threshold(band):
    f = band.ravel()
    p10 = float(np.percentile(f, 10))
    p90 = float(np.percentile(f, 90))
    return max(p10 + (p90 - p10) * 0.25, 10.0)


def _scan_stripes(band, thresh):
    h = band.shape[0]
    rows, centers, widths, stds = [], [], [], []
    for i in range(h // _STRIPE + 1):
        r0, r1 = i * _STRIPE, min((i + 1) * _STRIPE, h)
        cs, ws = [], []
        for r in range(r0, r1):
            s = np.convolve(band[r], np.ones(9) / 9, mode='same')
            b = np.where(s > thresh)[0]
            if len(b) > 10:
                cs.append((float(b[0]) + float(b[-1])) / 2.0)
                ws.append(float(b[-1] - b[0]))
        if len(cs) > 10:
            rows.append((r0 + r1) / 2.0)
            centers.append(float(np.median(cs)))
            widths.append(float(np.median(ws)))
            stds.append(float(np.std(cs)))
    return np.array(rows), np.array(centers), np.array(widths), np.array(stds)


def _wpolyfit(x, y, w, deg):
    deg = max(0, min(deg, len(x) - 1))
    W = np.diag(w / w.sum())
    V = np.vander(x, deg + 1)
    return np.linalg.lstsq(W @ V, W @ y, rcond=None)[0]


def _compute_shifts(sr, sc, ss):
    n = len(sr)
    reliable = ss < _STD_THRESHOLD
    if reliable.sum() < 4:
        reliable = np.ones(n, dtype=bool)

    idx_r = np.where(reliable)[0]
    ei = idx_r[idx_r % 2 == 0]
    oi = idx_r[idx_r % 2 == 1]
    if len(ei) == 0 or len(oi) == 0:
        return np.zeros(n)

    w_r = 1.0 / (ss[reliable] + 0.1)
    w_e = w_r[idx_r % 2 == 0]
    w_o = w_r[idx_r % 2 == 1]
    c_e = _wpolyfit(sr[ei], sc[ei], w_e, min(2, len(ei) - 1))
    c_o = _wpolyfit(sr[oi], sc[oi], w_o, min(2, len(oi) - 1))

    ideal = (np.polyval(c_e, sr) + np.polyval(c_o, sr)) / 2.0
    raw = sc - ideal
    re = np.where(reliable & (np.arange(n) % 2 == 0))[0]
    ro = np.where(reliable & (np.arange(n) % 2 == 1))[0]

    if len(re) < 2 or len(ro) < 2:
        return raw

    sc_e = np.polyfit(sr[re], raw[re], 1)
    sc_o = np.polyfit(sr[ro], raw[ro], 1)
    shifts = raw.copy()
    for i in range(n):
        if not reliable[i]:
            shifts[i] = np.polyval(sc_e if i % 2 == 0 else sc_o, sr[i])
    return shifts


def _apply_shifts(band, sr, shifts):
    h, w = band.shape
    out = band.copy()
    xs = np.arange(w, dtype=np.float32)
    for i, shift in enumerate(shifts):
        if abs(shift) < 0.3:
            continue
        r0 = max(0, int(sr[i] - _STRIPE / 2))
        r1 = min(h, int(sr[i] + _STRIPE / 2))
        src = np.clip(xs - shift, 0, w - 1)
        x0 = np.floor(src).astype(np.int32)
        x1 = np.minimum(x0 + 1, w - 1)
        t = (src - x0).astype(np.float32)
        for r in range(r0, r1):
            out[r] = band[r][x0] * (1 - t) + band[r][x1] * t
    return out


def _fit_squeeze(band, thresh):
    h = band.shape[0]
    rr, ww = [], []
    for i in range(h // _STRIPE + 1):
        r0, r1 = i * _STRIPE, min((i + 1) * _STRIPE, h)
        ws = []
        for r in range(r0, r1):
            s = np.convolve(band[r], np.ones(9) / 9, mode='same')
            b = np.where(s > thresh)[0]
            if len(b) > 10:
                ws.append(float(b[-1] - b[0]))
        if ws:
            rr.append((r0 + r1) / 2.0)
            ww.append(float(np.median(ws)))

    if len(rr) < 4:
        return 1.0
    rr, ww = np.array(rr), np.array(ww)

    def ew(r, cy, a, b):
        return 2 * b * np.sqrt(np.clip(1 - ((r - cy) / a) ** 2, 0, None))
    try:
        popt, _ = curve_fit(ew, rr, ww,
                            p0=[rr.mean(), (rr[-1] - rr[0]) / 2 * 1.2, ww.max() / 2],
                            maxfev=10000,
                            bounds=([0, 100, 100], [h * 2, h * 3, h]))
        return float(np.clip(popt[1] / popt[2], 1.0, 3.5))
    except Exception:
        return float(np.clip((rr[-1] - rr[0]) / ww.max(), 1.0, 3.5))


def destripe_and_squeeze(img, w, h, c, sensitivity=2.0):
    if isinstance(img, np.ndarray):
        arr = img.astype(np.float32)
    else:
        arr = np.array(img, dtype=np.float32)
    if arr.ndim == 2:
        arr = arr[:, :, np.newaxis]

    out_channels = []
    for ch in range(arr.shape[2]):
        band = arr[:, :, ch].copy()
        thresh = _threshold(band)
        sr, sc, sw, ss = _scan_stripes(band, thresh)
        if len(sr) < 4:
            out_channels.append(band)
            continue
        shifts = _compute_shifts(sr, sc, ss)
        if np.abs(shifts).max() < 1.5:
            out_channels.append(band)
            continue
        out_channels.append(_apply_shifts(band, sr, shifts))

    corrected = np.stack(out_channels, axis=2).clip(0, 255).astype(np.uint8)
    thresh0 = _threshold(corrected[:, :, 0].astype(np.float32))
    squeeze = _fit_squeeze(corrected[:, :, 0].astype(np.float32), thresh0)
    if squeeze < 1.05:
        return corrected

    img_h, img_w = corrected.shape[:2]
    new_h = max(100, int(round(img_h / squeeze)))
    return np.array(PILImage.fromarray(corrected).resize((img_w, new_h), PILImage.LANCZOS))


def destripe_fourier(img, w, h, c, sensitivity=2.0):
    return destripe_and_squeeze(img, w, h, c)

def destripe_fourier_aggressive(img, w, h, c):
    return destripe_and_squeeze(img, w, h, c)

def destripe_moment_matching_rows(img, window=50):
    arr = np.array(img) if not isinstance(img, np.ndarray) else img
    h, w = arr.shape[:2]
    c = 1 if arr.ndim == 2 else arr.shape[2]
    return destripe_and_squeeze(img, w, h, c)
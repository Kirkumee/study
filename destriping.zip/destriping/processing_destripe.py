import numpy as np
from scipy.signal import medfilt
from scipy.ndimage import gaussian_filter1d

def destripe_fourier(img, w, h, c, sensitivity=2.0):
    if isinstance(img, np.ndarray):
        arr = img.astype(np.float32)
    else:
        arr = np.array(img, dtype=np.float32)
    if arr.ndim == 2:
        arr = arr[:, :, np.newaxis]
    out_all = np.zeros_like(arr)

    for ch in range(arr.shape[2]):
        band = arr[:, :, ch].copy()
        img_h, img_w = band.shape
        rows = np.arange(img_h)
        seams = [0, img_h]

        for _ in range(3):
            limb_x = np.full(img_h, np.nan)
            for r in range(img_h):
                row_s = np.convolve(band[r], np.ones(5) / 5, mode='same')
                bright = np.where(row_s > 40)[0]
                if len(bright) > 10:
                    limb_x[r] = float(bright[0])

            valid = ~np.isnan(limb_x)
            if valid.sum() < 20:
                break

            limb_interp = np.interp(rows, rows[valid], limb_x[valid])
            limb_med = medfilt(limb_interp, kernel_size=5)
            win = min(201, (img_h // 6) | 1)
            limb_ideal = medfilt(limb_med, kernel_size=win)
            offset = medfilt(limb_med - limb_ideal, kernel_size=15)

            diff_o = np.diff(offset)
            seams = [0]
            last = -30
            for r, d in enumerate(diff_o):
                if abs(d) > sensitivity and (r - last) > 15:
                    seams.append(r + 1)
                    last = r
            seams.append(img_h)

            xs = np.arange(img_w)
            for i in range(len(seams) - 1):
                r0, r1 = seams[i], seams[i + 1]
                shift  = int(round(-float(np.median(offset[r0:r1]))))
                if shift == 0:
                    continue
                src_xs = np.clip(xs - shift, 0, img_w - 1)
                band[r0:r1] = band[r0:r1][:, src_xs]

        for b in seams[1:-1]:
            r0 = max(0, b - 10)
            r1 = min(img_h, b + 10)
            zone = band[r0:r1]
            blurred = gaussian_filter1d(zone, sigma=4, axis=0, mode='reflect')
            dist = np.abs(np.arange(r1 - r0) - (b - r0)).astype(np.float32)
            wt = np.clip(1.0 - dist / 10, 0, 1)[:, np.newaxis]
            band[r0:r1] = (1 - wt) * zone + wt * blurred
        out_all[:, :, ch] = band
    return np.clip(out_all, 0, 255).astype(np.uint8)

def destripe_fourier_aggressive(img, w, h, c):
    return destripe_fourier(img, w, h, c)

def destripe_moment_matching_rows(img, window=50):
    arr = np.array(img) if not isinstance(img, np.ndarray) else img
    h, w = arr.shape[:2]
    c = 1 if arr.ndim == 2 else arr.shape[2]
    return destripe_fourier(img, w, h, c)
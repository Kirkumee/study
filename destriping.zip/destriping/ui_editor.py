from PyQt5.QtWidgets import (
    QMainWindow, QLabel, QFileDialog, QMessageBox,
    QComboBox, QStatusBar, QWidget, QScrollArea, QSpinBox,
    QVBoxLayout, QHBoxLayout, QPushButton, QGroupBox,
    QGridLayout, QLineEdit, QDoubleSpinBox, QTabWidget,
    QAction, QApplication
)
from PyQt5.QtGui import QImage, QPixmap
from PyQt5.QtCore import Qt
import numpy as np
import processing_bmp
import processing_tiff
import processing_destripe
from formats import save_bmp, save_tiff

try:
    from matplotlib.backends.backend_qt5agg import FigureCanvasQTAgg as FigureCanvas
    from matplotlib.figure import Figure
    _MATPLOTLIB_OK = True
except ImportError:
    _MATPLOTLIB_OK = False


class HistogramWidget(FigureCanvas if _MATPLOTLIB_OK else QWidget):
    def __init__(self, parent=None):
        if _MATPLOTLIB_OK:
            self._fig = Figure(figsize=(5, 3), dpi=90, tight_layout=True)
            self._ax  = self._fig.add_subplot(111)
            super().__init__(self._fig)
        else:
            super().__init__(parent)
            self.setMinimumHeight(200)

        self._histograms = []
        self._stats = []

    def set_histograms(self, histograms):
        self._histograms = histograms
        self._redraw()

    def set_stats(self, stats):
        self._stats = stats
        self._redraw()

    def _redraw(self):
        if not _MATPLOTLIB_OK or not self._histograms:
            return

        ax = self._ax
        ax.clear()

        colors = ["#e74c3c", "#2ecc71", "#3498db"]
        names  = ["Красный", "Зелёный", "Синий"]
        xs     = np.arange(256)

        for ch, hist in enumerate(self._histograms):
            if not hist:
                continue
            label = names[ch] if len(self._histograms) == 3 else "Gray"
            color = colors[ch] if len(self._histograms) == 3 else "#555555"

            vals = np.array(hist, dtype=np.float64)
            ax.fill_between(xs, vals, alpha=0.55, color=color, label=label)
            ax.plot(xs, vals, color=color, linewidth=0.8, alpha=0.8)

            if ch < len(self._stats):
                mean, std = self._stats[ch]
                ax.axvline(mean, color=color, linestyle="--", linewidth=1.2,
                           alpha=0.9, label=f"μ={mean:.1f} σ={std:.1f}")

        ax.set_xlim(0, 255)
        ax.set_xlabel("Значение пикселя", fontsize=8)
        ax.set_ylabel("Количество", fontsize=8)
        ax.set_title("Гистограмма", fontsize=9)
        ax.tick_params(labelsize=7)
        ax.legend(fontsize=7, loc="upper right")
        ax.grid(True, alpha=0.3, linewidth=0.5)

        self._fig.tight_layout()
        self.draw()

class ImageLabel(QLabel):
    def __init__(self, parent):
        super().__init__(parent)
        self._editor = parent
        self.setAlignment(Qt.AlignCenter)
        self.setMouseTracking(True)

    def mouseMoveEvent(self, e):
        pixmap = self.pixmap()
        if pixmap is None:
            return

        lw, lh = self.width(), self.height()
        pw, ph = pixmap.width(), pixmap.height()

        x_off = (lw - pw) / 2 if pw < lw else 0
        y_off = (lh - ph) / 2 if ph < lh else 0

        scale  = self._editor.current_scale
        img_x  = int((e.x() - x_off) / scale)
        img_y  = int((e.y() - y_off) / scale)

        w = self._editor.w
        h = self._editor.h
        c = self._editor.c

        if 0 <= img_x < w and 0 <= img_y < h:
            arr = self._editor.dst_img
            px  = arr[img_y, img_x] if isinstance(arr, np.ndarray) else arr[img_y][img_x]
            if c == 3:
                info = f"RGB=({int(px[0])}, {int(px[1])}, {int(px[2])})"
            else:
                info = f"Gray=({int(px[0])})"
            self._editor.status_bar.showMessage(
                f"x={img_x}, y={img_y} | {info} | Масштаб: {scale:.2f}×"
            )

    def wheelEvent(self, event):
        self._editor.handle_wheel_event(event)

class ImageEditor(QMainWindow):
    def __init__(self, data, ftype):
        super().__init__()
        self.setWindowTitle(f"Редактор {ftype} изображения")
        self.resize(1400, 800)

        self.w = data["w"]
        self.h = data["h"]
        self.c  = data["c"]
        self.bps = data.get("bps", 8)
        self.ftype = ftype

        src = data["img"]
        self.src_img = src if isinstance(src, np.ndarray) else np.array(src, dtype=np.uint8)
        self.dst_img = self.src_img.copy()

        self.current_scale = 1.0
        self.min_scale     = 0.05
        self.max_scale     = 8.0

        self._build_ui()
        self.show_image()
        self.update_histogram()

    def _build_ui(self):
        self.create_menu()

        self.status_bar = QStatusBar()
        self.setStatusBar(self.status_bar)

        central = QWidget()
        self.setCentralWidget(central)
        main_layout = QHBoxLayout(central)

        left_panel = QVBoxLayout()
        left_panel.setSpacing(8)

        info_group  = QGroupBox("Информация")
        info_layout = QGridLayout()
        self.info_size     = QLabel(f"Размер: {self.w} × {self.h}")
        self.info_channels = QLabel(f"Каналы: {self.c} ({'RGB' if self.c == 3 else 'Gray'})")
        self.info_depth    = QLabel(f"Глубина: {self.bps}-bit")
        self.info_format   = QLabel(f"Формат: {self.ftype}")
        self.info_scale    = QLabel("Масштаб: 100%")
        for i, lbl in enumerate([self.info_size, self.info_channels,
                                  self.info_depth, self.info_format, self.info_scale]):
            info_layout.addWidget(lbl, i, 0, 1, 2)
        info_group.setLayout(info_layout)
        left_panel.addWidget(info_group)

        zoom_group  = QGroupBox("Масштабирование")
        zoom_layout = QGridLayout()
        b_in  = QPushButton("+ Увеличить");  b_in.clicked.connect(lambda: self.zoom_image(1.25))
        b_out = QPushButton("− Уменьшить");  b_out.clicked.connect(lambda: self.zoom_image(0.8))
        b_100 = QPushButton("100%");         b_100.clicked.connect(lambda: self.set_scale(1.0))
        b_fit = QPushButton("По размеру");   b_fit.clicked.connect(self.zoom_to_fit)
        zoom_layout.addWidget(b_in,  0, 0)
        zoom_layout.addWidget(b_out, 0, 1)
        zoom_layout.addWidget(b_100, 1, 0)
        zoom_layout.addWidget(b_fit, 1, 1)
        zoom_group.setLayout(zoom_layout)
        left_panel.addWidget(zoom_group)

        if self.ftype == "BMP":
            self.setup_bmp_tools(left_panel)
        else:
            self.setup_tiff_tools(left_panel)

        self.setup_common_tools(left_panel)
        self.setup_destripe_tools(left_panel)
        left_panel.addStretch()

        right_panel = QVBoxLayout()
        self.tab_widget = QTabWidget()

        img_tab = QWidget()
        img_layout = QVBoxLayout(img_tab)
        self.label = ImageLabel(self)
        scroll = QScrollArea()
        scroll.setWidget(self.label)
        scroll.setWidgetResizable(True)
        img_layout.addWidget(scroll)
        self.tab_widget.addTab(img_tab, "Изображение")

        hist_tab = QWidget()
        hist_layout = QVBoxLayout(hist_tab)
        self.histogram_widget = HistogramWidget()
        hist_layout.addWidget(self.histogram_widget)
        self.tab_widget.addTab(hist_tab, "Гистограмма")

        right_panel.addWidget(self.tab_widget)

        main_layout.addLayout(left_panel,  1)
        main_layout.addLayout(right_panel, 3)

    def create_menu(self):
        menubar = self.menuBar()

        file_menu = menubar.addMenu("&Файл")
        label = "Сохранить как BMP..." if self.ftype == "BMP" else "Сохранить как TIFF..."
        save_action = QAction(label, self)
        save_action.triggered.connect(lambda: self.save_image(self.ftype))
        file_menu.addAction(save_action)
        file_menu.addSeparator()
        exit_action = QAction("Закрыть", self)
        exit_action.triggered.connect(self.close)
        file_menu.addAction(exit_action)

        view_menu = menubar.addMenu("&Вид")
        hist_action = QAction("Показать гистограмму", self)
        hist_action.triggered.connect(lambda: self.tab_widget.setCurrentIndex(1))
        view_menu.addAction(hist_action)

    def setup_bmp_tools(self, panel):
        g = QGroupBox("Контрастирование");  gl = QVBoxLayout()
        self.combo_contrast = QComboBox();   self.combo_contrast.addItems(["Деление разрядности"])
        b = QPushButton("Применить");        b.clicked.connect(self.apply_bmp_contrast)
        gl.addWidget(self.combo_contrast);   gl.addWidget(b)
        g.setLayout(gl);                     panel.addWidget(g)

        g = QGroupBox("Негатив");  gl = QVBoxLayout()
        b = QPushButton("Применить");  b.clicked.connect(self.apply_bmp_negative)
        gl.addWidget(b);  g.setLayout(gl);  panel.addWidget(g)

        g = QGroupBox("Изменение размера");  gl = QGridLayout()
        gl.addWidget(QLabel("Коэффициент:"), 0, 0)
        self.spin_scale = QSpinBox();  self.spin_scale.setRange(1, 10);  self.spin_scale.setValue(2)
        gl.addWidget(self.spin_scale, 0, 1)
        self.combo_scale = QComboBox()
        self.combo_scale.addItems(["Прореживание (уменьшение)", "Усреднение (уменьшение)", "Билинейная (ув./ум.)"])
        gl.addWidget(self.combo_scale, 1, 0, 1, 2)
        b = QPushButton("Изменить");  b.clicked.connect(self.apply_bmp_scale)
        gl.addWidget(b, 2, 0, 1, 2)
        g.setLayout(gl);  panel.addWidget(g)

        g = QGroupBox("Поворот");  gl = QGridLayout()
        gl.addWidget(QLabel("Угол (°):"), 0, 0)
        self.spin_angle = QDoubleSpinBox()
        self.spin_angle.setRange(-360, 360);  self.spin_angle.setValue(45);  self.spin_angle.setSingleStep(5)
        gl.addWidget(self.spin_angle, 0, 1)
        self.combo_rotate = QComboBox();  self.combo_rotate.addItems(["Аффинный", "Билинейный"])
        gl.addWidget(self.combo_rotate, 1, 0, 1, 2)
        b = QPushButton("Повернуть");  b.clicked.connect(self.apply_bmp_rotate)
        gl.addWidget(b, 2, 0, 1, 2)
        g.setLayout(gl);  panel.addWidget(g)

        g = QGroupBox("Фильтры");  gl = QGridLayout()
        gl.addWidget(QLabel("Размер ядра:"), 0, 0)
        self.spin_kernel = QSpinBox()
        self.spin_kernel.setRange(3, 15);  self.spin_kernel.setValue(3);  self.spin_kernel.setSingleStep(2)
        gl.addWidget(self.spin_kernel, 0, 1)
        self.combo_filter = QComboBox();  self.combo_filter.addItems(["Средний", "Медианный"])
        gl.addWidget(self.combo_filter, 1, 0, 1, 2)
        b = QPushButton("Применить");  b.clicked.connect(self.apply_bmp_filter)
        gl.addWidget(b, 2, 0, 1, 2)
        g.setLayout(gl);  panel.addWidget(g)

        g = QGroupBox("Свёртка 3×3");  gl = QVBoxLayout()
        gl.addWidget(QLabel("Матрица ядра:"))
        self.matrix_inputs = []
        ml = QGridLayout()
        for i in range(3):
            row = []
            for j in range(3):
                le = QLineEdit("1" if i == 1 and j == 1 else "0")
                le.setMaximumWidth(50)
                ml.addWidget(le, i, j)
                row.append(le)
            self.matrix_inputs.append(row)
        gl.addLayout(ml)
        pl = QHBoxLayout()
        pl.addWidget(QLabel("M:"))
        self.edit_m = QLineEdit("1.0");  self.edit_m.setMaximumWidth(50)
        pl.addWidget(self.edit_m)
        pl.addWidget(QLabel("O:"))
        self.edit_o = QLineEdit("0.0");  self.edit_o.setMaximumWidth(50)
        pl.addWidget(self.edit_o)
        gl.addLayout(pl)
        b = QPushButton("Применить свёртку");  b.clicked.connect(self.apply_bmp_convolution)
        gl.addWidget(b);  g.setLayout(gl);  panel.addWidget(g)

    def setup_tiff_tools(self, panel):
        g = QGroupBox("Контрастирование");  gl = QVBoxLayout()
        self.combo_contrast = QComboBox()
        self.combo_contrast.addItems(["Деление разрядности", "Линейное (z = 2%)", "Линейное (nonzero)"])
        b = QPushButton("Применить");  b.clicked.connect(self.apply_tiff_contrast)
        gl.addWidget(self.combo_contrast);  gl.addWidget(b)
        g.setLayout(gl);  panel.addWidget(g)

        g = QGroupBox("Негатив");  gl = QVBoxLayout()
        b = QPushButton("Применить");  b.clicked.connect(self.apply_tiff_negative)
        gl.addWidget(b);  g.setLayout(gl);  panel.addWidget(g)

        g = QGroupBox("Изменение размера");  gl = QGridLayout()
        gl.addWidget(QLabel("Коэффициент:"), 0, 0)
        self.spin_scale = QSpinBox();  self.spin_scale.setRange(1, 10);  self.spin_scale.setValue(2)
        gl.addWidget(self.spin_scale, 0, 1)
        self.combo_scale = QComboBox()
        self.combo_scale.addItems(["Усреднение (уменьшение)", "Билинейная (ув./ум.)"])
        gl.addWidget(self.combo_scale, 1, 0, 1, 2)
        b = QPushButton("Изменить");  b.clicked.connect(self.apply_tiff_scale)
        gl.addWidget(b, 2, 0, 1, 2)
        g.setLayout(gl);  panel.addWidget(g)

        g = QGroupBox("Поворот");  gl = QGridLayout()
        gl.addWidget(QLabel("Угол (°):"), 0, 0)
        self.spin_angle = QDoubleSpinBox()
        self.spin_angle.setRange(-360, 360);  self.spin_angle.setValue(45);  self.spin_angle.setSingleStep(5)
        gl.addWidget(self.spin_angle, 0, 1)
        self.combo_rotate = QComboBox();  self.combo_rotate.addItems(["Билинейный"])
        gl.addWidget(self.combo_rotate, 1, 0, 1, 2)
        b = QPushButton("Повернуть");  b.clicked.connect(self.apply_tiff_rotate)
        gl.addWidget(b, 2, 0, 1, 2)
        g.setLayout(gl);  panel.addWidget(g)

        g = QGroupBox("Фильтры");  gl = QGridLayout()
        gl.addWidget(QLabel("Размер ядра:"), 0, 0)
        self.spin_kernel = QSpinBox()
        self.spin_kernel.setRange(3, 15);  self.spin_kernel.setValue(3);  self.spin_kernel.setSingleStep(2)
        gl.addWidget(self.spin_kernel, 0, 1)
        self.combo_filter = QComboBox();  self.combo_filter.addItems(["Медианный"])
        gl.addWidget(self.combo_filter, 1, 0, 1, 2)
        b = QPushButton("Применить");  b.clicked.connect(self.apply_tiff_filter)
        gl.addWidget(b, 2, 0, 1, 2)
        g.setLayout(gl);  panel.addWidget(g)

        g = QGroupBox("Сглаживающий фильтр 3×3");  gl = QVBoxLayout()
        b = QPushButton("Применить");  b.clicked.connect(self.apply_tiff_convolution_smooth)
        gl.addWidget(b);  g.setLayout(gl);  panel.addWidget(g)

    def setup_common_tools(self, panel):
        g = QGroupBox("Статистика");  gl = QVBoxLayout()
        b = QPushButton("Показать статистику");  b.clicked.connect(self.show_stats)
        gl.addWidget(b);  g.setLayout(gl);  panel.addWidget(g)

    def setup_destripe_tools(self, panel):
        g = QGroupBox("Выравнивание полос")
        gl = QVBoxLayout()

        row = QHBoxLayout()
        row.addWidget(QLabel("Чувствительность:"))
        self.spin_destripe_sens = QDoubleSpinBox()
        self.spin_destripe_sens.setRange(0.5, 10.0)
        self.spin_destripe_sens.setSingleStep(0.5)
        self.spin_destripe_sens.setValue(2.0)
        self.spin_destripe_sens.setDecimals(1)
        self.spin_destripe_sens.setToolTip(
            "Порог обнаружения границ полос (пиксели).\n"
            "1.0–2.0 — ловит мелкие сдвиги\n"
            "3.0–5.0 — только крупные ступеньки"
        )
        row.addWidget(self.spin_destripe_sens)
        gl.addLayout(row)

        btn_apply = QPushButton("Выровнять полосы")
        btn_apply.clicked.connect(self.apply_destripe_moment)
        btn_apply.setStyleSheet("background-color: #4CAF50; color: white; font-weight: bold;")
        gl.addWidget(btn_apply)

        self.destripe_progress = QLabel("")
        self.destripe_progress.setAlignment(Qt.AlignCenter)
        gl.addWidget(self.destripe_progress)

        g.setLayout(gl)
        panel.addWidget(g)

    def apply_destripe_moment(self):
        try:
            self.destripe_progress.setText("Обработка...")
            QApplication.processEvents()

            sensitivity = self.spin_destripe_sens.value()
            result = processing_destripe.destripe_fourier(
                self.dst_img, self.w, self.h, self.c,
                sensitivity=sensitivity
            )

            if result is not None:
                self.dst_img = result
                self.show_image()
                self.update_histogram()
                self.destripe_progress.setText("Готово!")
                self.status_bar.showMessage(
                    f"Полосы выровнены (чувствительность={sensitivity:.1f})", 3000
                )
        except Exception as e:
            self.destripe_progress.setText("Ошибка!")
            QMessageBox.warning(self, "Ошибка", str(e))

    def apply_bmp_contrast(self):
        self._apply(lambda: processing_bmp.bmp_contrast_divide(self.dst_img, self.w, self.h, self.c))

    def apply_bmp_negative(self):
        self._apply(lambda: processing_bmp.bmp_negative(self.dst_img, self.w, self.h, self.c))

    def apply_bmp_scale(self):
        n = self.spin_scale.value()
        m = self.combo_scale.currentIndex()
        try:
            if m == 0:
                if n <= 1: return self._warn("Прореживание: коэффициент должен быть > 1")
                out, nw, nh = processing_bmp.bmp_scale_thin(self.dst_img, self.w, self.h, self.c, n)
                self.dst_img = out;  self.w = nw;  self.h = nh
                self.info_size.setText(f"Размер: {nw} × {nh}")
            elif m == 1:
                if n <= 1: return self._warn("Усреднение: коэффициент должен быть > 1")
                out, nw, nh = processing_bmp.bmp_scale_avg(self.dst_img, self.w, self.h, self.c, n)
                self.dst_img = out;  self.w = nw;  self.h = nh
                self.info_size.setText(f"Размер: {nw} × {nh}")
            else:
                if n < 1: return self._warn("Коэффициент должен быть ≥ 1")
                nw, nh = self.w * n, self.h * n
                self.dst_img = self._bilinear(self.dst_img, self.w, self.h, self.c, nw, nh)
                self.w = nw;  self.h = nh
                self.info_size.setText(f"Размер: {nw} × {nh}")
            self.show_image()
            self.update_histogram()
            self.status_bar.showMessage(f"Размер изменён: {self.w}×{self.h}", 3000)
        except Exception as e:
            QMessageBox.warning(self, "Ошибка", str(e))

    def apply_bmp_rotate(self):
        angle = self.spin_angle.value()
        m     = self.combo_rotate.currentIndex()
        fn    = processing_bmp.bmp_rotate_affine if m == 0 else processing_bmp.bmp_rotate_bilinear
        self._apply(lambda: fn(self.dst_img, self.w, self.h, self.c, angle))

    def apply_bmp_filter(self):
        k = self.spin_kernel.value()
        m = self.combo_filter.currentIndex()
        fn = processing_bmp.bmp_mean_filter if m == 0 else processing_bmp.bmp_median_filter
        self._apply(lambda: fn(self.dst_img, self.w, self.h, self.c, k))

    def apply_bmp_convolution(self):
        try:
            A = [[float(self.matrix_inputs[i][j].text()) for j in range(3)] for i in range(3)]
            M = float(self.edit_m.text())
            O = float(self.edit_o.text())
            self._apply(lambda: processing_bmp.bmp_convolution(self.dst_img, self.w, self.h, self.c, A, M, O))
        except ValueError:
            QMessageBox.warning(self, "Ошибка", "Неверный формат чисел в матрице или параметрах M/O")

    def apply_tiff_contrast(self):
        idx = self.combo_contrast.currentIndex()
        fns = [processing_tiff.tiff_contrast_divide,
               processing_tiff.tiff_contrast_linear_z,
               processing_tiff.tiff_contrast_linear_nz]
        self._apply(lambda: fns[idx](self.dst_img, self.w, self.h, self.c))

    def apply_tiff_negative(self):
        self._apply(lambda: processing_tiff.tiff_negative(self.dst_img, self.w, self.h, self.c))

    def apply_tiff_scale(self):
        n = self.spin_scale.value()
        m = self.combo_scale.currentIndex()
        try:
            if m == 0:
                if n <= 1: return self._warn("Усреднение: коэффициент должен быть > 1")
                out, nw, nh = processing_tiff.tiff_scale_avg(self.dst_img, self.w, self.h, self.c, n)
                self.dst_img = out;  self.w = nw;  self.h = nh
                self.info_size.setText(f"Размер: {nw} × {nh}")
            else:
                if n < 1: return self._warn("Коэффициент должен быть ≥ 1")
                nw, nh = self.w * n, self.h * n
                self.dst_img = self._bilinear(self.dst_img, self.w, self.h, self.c, nw, nh)
                self.w = nw;  self.h = nh
                self.info_size.setText(f"Размер: {nw} × {nh}")
            self.show_image()
            self.update_histogram()
            self.status_bar.showMessage(f"Размер изменён: {self.w}×{self.h}", 3000)
        except Exception as e:
            QMessageBox.warning(self, "Ошибка", str(e))

    def apply_tiff_rotate(self):
        angle = self.spin_angle.value()
        self._apply(lambda: processing_tiff.tiff_rotate_bilinear(self.dst_img, self.w, self.h, self.c, angle))

    def apply_tiff_filter(self):
        k = self.spin_kernel.value()
        self._apply(lambda: processing_tiff.tiff_median_filter(self.dst_img, self.w, self.h, self.c, k))

    def apply_tiff_convolution_smooth(self):
        self._apply(lambda: processing_tiff.tiff_convolution_smooth(self.dst_img, self.w, self.h, self.c))

    def show_stats(self):
        try:
            if self.ftype == "BMP":
                stats = processing_bmp.bmp_mean_std(self.dst_img, self.w, self.h, self.c)
            else:
                stats = processing_tiff.tiff_mean_std(self.dst_img, self.w, self.h, self.c)

            if self.c == 1:
                msg = f"Gray: μ={stats[0][0]:.2f}, σ={stats[0][1]:.2f}"
            else:
                msg = "\n".join(
                    f"{ch}: μ={stats[i][0]:.2f}, σ={stats[i][1]:.2f}"
                    for i, ch in enumerate(["R", "G", "B"])
                )
            QMessageBox.information(self, f"Статистика ({self.ftype})", msg)
        except Exception as e:
            QMessageBox.warning(self, "Ошибка", str(e))

    def save_image(self, fmt):
        if fmt == "BMP":
            fname, _ = QFileDialog.getSaveFileName(self, "Сохранить как BMP", "", "BMP (*.bmp)")
            fn = save_bmp
        else:
            fname, _ = QFileDialog.getSaveFileName(self, "Сохранить как TIFF", "", "TIFF (*.tif *.tiff)")
            fn = save_tiff

        if not fname:
            return
        try:
            fn(fname, {"w": self.w, "h": self.h, "c": self.c, "img": self.dst_img})
            self.status_bar.showMessage(f"Сохранено: {fname.split('/')[-1]}", 5000)
        except Exception as e:
            QMessageBox.warning(self, "Ошибка", str(e))

    def handle_wheel_event(self, event):
        if event.modifiers() & Qt.ControlModifier:
            self.zoom_image(1.2 if event.angleDelta().y() > 0 else 1 / 1.2)
            event.accept()
        else:
            event.ignore()

    def zoom_image(self, factor):
        self.set_scale(self.current_scale * factor)

    def set_scale(self, scale):
        self.current_scale = max(self.min_scale, min(self.max_scale, scale))
        self.info_scale.setText(f"Масштаб: {int(self.current_scale * 100)}%")
        self.show_image()

    def zoom_to_fit(self):
        try:
            scroll = self.label.parentWidget().parentWidget()
            if hasattr(scroll, "viewport"):
                vp   = scroll.viewport().size()
                sw   = max(vp.width()  - 40, 1)
                sh   = max(vp.height() - 40, 1)
                self.set_scale(min(sw / self.w, sh / self.h))
        except Exception:
            pass

    def show_image(self):
        try:
            arr = self.dst_img
            if not isinstance(arr, np.ndarray):
                arr = np.array(arr, dtype=np.uint8)

            if arr.ndim == 2:
                arr = np.stack([arr, arr, arr], axis=2)
            elif arr.shape[2] == 1:
                arr = np.repeat(arr, 3, axis=2)

            dh = max(1, int(self.h * self.current_scale))
            dw = max(1, int(self.w * self.current_scale))

            if dh != self.h or dw != self.w:
                yi = np.clip((np.arange(dh) * self.h / dh).astype(np.int32), 0, self.h - 1)
                xi = np.clip((np.arange(dw) * self.w / dw).astype(np.int32), 0, self.w - 1)
                arr = arr[np.ix_(yi, xi)]

            arr = np.ascontiguousarray(np.clip(arr[:, :, :3], 0, 255).astype(np.uint8))
            qimg = QImage(arr.data, dw, dh, dw * 3, QImage.Format_RGB888)
            self.label.setPixmap(QPixmap.fromImage(qimg.copy()))
            self.label.resize(dw, dh)

        except Exception as e:
            print(f"Ошибка отображения: {e}")

    def update_histogram(self):
        try:
            arr = self.dst_img
            if not isinstance(arr, np.ndarray):
                arr = np.array(arr, dtype=np.uint8)
            if arr.ndim == 2:
                arr = arr[:, :, np.newaxis]

            arr8 = np.clip(arr, 0, 255).astype(np.uint8)
            hists = [
                np.histogram(arr8[:, :, ch].ravel(), bins=256, range=(0, 255))[0].tolist()
                for ch in range(arr8.shape[2])
            ]
            stats = [
                (float(arr8[:, :, ch].mean()), float(arr8[:, :, ch].std()))
                for ch in range(arr8.shape[2])
            ]
            self.histogram_widget.set_histograms(hists)
            self.histogram_widget.set_stats(stats)
        except Exception as e:
            print(f"Ошибка гистограммы: {e}")

    def _bilinear(self, img, w, h, c, new_w, new_h):
        from PIL import Image
        arr = img if isinstance(img, np.ndarray) else np.array(img, dtype=np.uint8)
        if arr.ndim == 2:
            arr = arr[:, :, np.newaxis]
        if arr.shape[2] == 1:
            pil_img = Image.fromarray(arr[:, :, 0], mode="L")
            out = np.array(pil_img.resize((new_w, new_h), Image.BILINEAR), dtype=np.uint8)[:, :, np.newaxis]
        else:
            pil_img = Image.fromarray(arr[:, :, :3], mode="RGB")
            out = np.array(pil_img.resize((new_w, new_h), Image.BILINEAR), dtype=np.uint8)
        return out

    def _apply(self, fn):
        try:
            result = fn()
            if result is not None:
                self.dst_img = result
            self.show_image()
            self.update_histogram()
            self.status_bar.showMessage("Применено", 2000)
        except Exception as e:
            QMessageBox.warning(self, "Ошибка", str(e))

    def _warn(self, msg):
        QMessageBox.warning(self, "Внимание", msg)
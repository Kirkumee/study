from PyQt5.QtWidgets import (
    QMainWindow, QWidget, QMessageBox,
    QVBoxLayout, QHBoxLayout,
    QPushButton, QLabel,
    QFileDialog, QScrollArea, QGroupBox, QGridLayout,
    QAction, QStatusBar
)
from PyQt5.QtCore import Qt
from PyQt5.QtGui import QImage, QPixmap
import numpy as np
from formats import read_bmp, read_tiff, save_bmp, save_tiff
from ui_editor import ImageEditor

class MainMenu(QMainWindow):
    def __init__(self):
        super().__init__()
        self.setWindowTitle("Обработка изображений BMP и TIFF")
        self.resize(1200, 800)
        self.setMinimumSize(1000, 600)

        self.create_menu()

        self.statusBar = QStatusBar()
        self.setStatusBar(self.statusBar)
        self.statusBar.showMessage("Готово. Выберите файл через меню 'Файл'")

        central = QWidget(self)
        self.setCentralWidget(central)

        root = QHBoxLayout(central)
        root.setContentsMargins(10, 10, 10, 10)
        root.setSpacing(10)

        left_panel = QVBoxLayout()
        left_panel.setSpacing(15)

        info_group = QGroupBox("Информация о изображении")
        info_layout = QGridLayout()

        self.info_format   = QLabel("Формат: -")
        self.info_size     = QLabel("Размер: -")
        self.info_channels = QLabel("Каналы: -")
        self.info_bitdepth = QLabel("Глубина: -")
        self.info_filename = QLabel("Файл: -")

        info_layout.addWidget(self.info_format,   0, 0, 1, 2)
        info_layout.addWidget(self.info_size,     1, 0, 1, 2)
        info_layout.addWidget(self.info_channels, 2, 0, 1, 2)
        info_layout.addWidget(self.info_bitdepth, 3, 0, 1, 2)
        info_layout.addWidget(self.info_filename, 4, 0, 1, 2)

        info_group.setLayout(info_layout)
        left_panel.addWidget(info_group)

        btn_group = QGroupBox("Редактор")
        btn_layout = QVBoxLayout()

        self.btn_editor = QPushButton("Открыть редактор")
        self.btn_editor.setMinimumHeight(40)
        self.btn_editor.clicked.connect(self.open_editor)
        self.btn_editor.setEnabled(False)

        btn_layout.addWidget(self.btn_editor)
        btn_group.setLayout(btn_layout)
        left_panel.addWidget(btn_group)

        about_group = QGroupBox("Справка")
        about_layout = QVBoxLayout()
        about_label = QLabel(
            "Поддерживаемые форматы:\n"
            "- BMP (8-bit, 24-bit)\n"
            "- TIFF (8-bit, 16-bit)\n\n"
            "Функции редактора:\n"
            "- Контрастирование\n"
            "- Негатив\n"
            "- Масштабирование\n"
            "- Поворот\n"
            "- Фильтры\n"
            "- Свёртка\n"
            "- Статистика\n"
            "- Гистограмма (matplotlib)"
        )
        about_label.setStyleSheet("font-size: 11px; padding: 5px;")
        about_layout.addWidget(about_label)
        about_group.setLayout(about_layout)
        left_panel.addWidget(about_group)
        left_panel.addStretch()

        root.addLayout(left_panel, 1)

        right_panel = QVBoxLayout()
        right_panel.setSpacing(10)

        preview_group = QGroupBox("Предпросмотр изображения")
        preview_layout = QVBoxLayout()

        self.image_label = QLabel()
        self.image_label.setAlignment(Qt.AlignCenter)
        self.image_label.setText("Откройте файл изображения\nчерез меню 'Файл' → 'Открыть'")
        self.image_label.setStyleSheet("""
            font-size: 14px;
            color: gray;
            padding: 20px;
            border: 1px dashed #aaa;
        """)

        scroll = QScrollArea()
        scroll.setWidget(self.image_label)
        scroll.setWidgetResizable(True)
        scroll.setMinimumHeight(500)

        preview_layout.addWidget(scroll)
        preview_group.setLayout(preview_layout)
        right_panel.addWidget(preview_group)

        root.addLayout(right_panel, 3)

        self.current_data  = None
        self.current_fname = None
        self.current_ftype = None

        self.image_label.setMouseTracking(True)
        self.image_label.mouseMoveEvent = self.preview_mouse_move

    def create_menu(self):
        menubar = self.menuBar()

        file_menu = menubar.addMenu("&Файл")

        open_action = QAction("Открыть...", self)
        open_action.triggered.connect(self.open_file)
        file_menu.addAction(open_action)

        file_menu.addSeparator()

        save_action = QAction("Сохранить...", self)
        save_action.triggered.connect(self.save_file)
        save_action.setEnabled(False)
        self.save_action = save_action
        file_menu.addAction(save_action)

        file_menu.addSeparator()

        exit_action = QAction("Выход", self)
        exit_action.triggered.connect(self.close)
        file_menu.addAction(exit_action)


    def preview_mouse_move(self, event):
        if self.current_data is None:
            return

        pixmap = self.image_label.pixmap()
        if pixmap is None:
            return

        pw = pixmap.width()
        ph = pixmap.height()
        lw = self.image_label.width()
        lh = self.image_label.height()

        x_off = (lw - pw) / 2 if pw < lw else 0
        y_off = (lh - ph) / 2 if ph < lh else 0

        img_x = int(event.x() - x_off)
        img_y = int(event.y() - y_off)

        w = self.current_data["w"]
        h = self.current_data["h"]
        c = self.current_data["c"]

        if 0 <= img_x < w and 0 <= img_y < h:
            arr = self.current_data["img"]
            px = arr[img_y, img_x] if isinstance(arr, np.ndarray) else arr[img_y][img_x]
            if c == 3:
                r, g, b = int(px[0]), int(px[1]), int(px[2])
                info = f"RGB=({r}, {g}, {b})"
            else:
                gray = int(px[0])
                info = f"Gray=({gray})"
            self.statusBar.showMessage(f"x={img_x}, y={img_y} | {info}")

    def open_file(self):
        fname, _ = QFileDialog.getOpenFileName(
            self, "Выберите файл изображения", "",
            "Изображения (*.bmp *.tif *.tiff);;BMP Files (*.bmp);;TIFF Files (*.tif *.tiff);;All Files (*.*)"
        )

        if not fname:
            return

        fname_lower = fname.lower()

        try:
            if fname_lower.endswith(".bmp"):
                data  = read_bmp(fname)
                ftype = "BMP"
            elif fname_lower.endswith(".tif") or fname_lower.endswith(".tiff"):
                data  = read_tiff(fname)
                ftype = "TIFF"
            else:
                QMessageBox.critical(self, "Ошибка",
                    "Неподдерживаемый формат файла.\n"
                    "Поддерживаются только BMP и TIFF файлы.")
                return

            self.current_data  = data
            self.current_fname = fname
            self.current_ftype = ftype

            self.update_file_info(data, fname, ftype)
            self.show_image(data)
            self.btn_editor.setEnabled(True)
            self.save_action.setEnabled(True)

            short = fname.replace("\\", "/").split("/")[-1]
            self.statusBar.showMessage(f"Загружен файл: {short} ({ftype})")

        except Exception as e:
            QMessageBox.critical(self, "Ошибка", f"Не удалось загрузить файл:\n{e}")

    def open_editor(self):
        if self.current_data is None:
            QMessageBox.warning(self, "Внимание", "Сначала откройте файл!")
            return

        self.editor = ImageEditor(dict(self.current_data), self.current_ftype)
        self.editor.show()

    def save_file(self):
        if self.current_data is None:
            QMessageBox.warning(self, "Внимание", "Нет данных для сохранения!")
            return

        if self.current_ftype == "BMP":
            fname, _ = QFileDialog.getSaveFileName(self, "Сохранить как BMP", "", "BMP (*.bmp)")
            if not fname:
                return
            try:
                save_bmp(fname, self.current_data)
                short = fname.replace("\\", "/").split("/")[-1]
                self.statusBar.showMessage(f"Файл сохранен: {short}")
                QMessageBox.information(self, "Успех", f"Файл сохранен:\n{short}")
            except Exception as e:
                QMessageBox.critical(self, "Ошибка", f"Ошибка сохранения BMP:\n{e}")

        elif self.current_ftype == "TIFF":
            fname, _ = QFileDialog.getSaveFileName(self, "Сохранить как TIFF", "", "TIFF (*.tif *.tiff)")
            if not fname:
                return
            try:
                save_tiff(fname, self.current_data)
                short = fname.replace("\\", "/").split("/")[-1]
                self.statusBar.showMessage(f"Файл сохранен: {short}")
                QMessageBox.information(self, "Успех", f"Файл сохранен:\n{short}")
            except Exception as e:
                QMessageBox.critical(self, "Ошибка", f"Ошибка сохранения TIFF:\n{e}")

    def update_file_info(self, data, fname, ftype):
        short = fname.replace("\\", "/").split("/")[-1]
        if len(short) > 40:
            short = short[:37] + "..."

        self.info_filename.setText(f"Файл: {short}")
        self.info_format.setText(f"Формат: {ftype}")
        self.info_size.setText(f"Размер: {data['w']} × {data['h']} пикселей")
        self.info_channels.setText(f"Каналы: {data['c']} ({'RGB' if data['c'] == 3 else 'Grayscale'})")
        self.info_bitdepth.setText(f"Глубина цвета: {data.get('bps', 8)}-bit")
        self.setWindowTitle(f"Image Processing — {short}")

    def show_image(self, data):
        try:
            arr = data["img"]
            if not isinstance(arr, np.ndarray):
                arr = np.array(arr, dtype=np.uint8)
            if arr.ndim == 2:
                arr = np.stack([arr, arr, arr], axis=2)
            elif arr.shape[2] == 1:
                arr = np.repeat(arr, 3, axis=2)

            arr = np.ascontiguousarray(np.clip(arr[:, :, :3], 0, 255).astype(np.uint8))
            h, w = arr.shape[:2]

            qimg = QImage(arr.data, w, h, w * 3, QImage.Format_RGB888)
            self.image_label.setPixmap(QPixmap.fromImage(qimg.copy()))
            self.image_label.resize(w, h)
            self.image_label.setStyleSheet("border: none;")

        except Exception as e:
            print(f"Ошибка при отображении: {e}")
            self.image_label.setText(f"Ошибка отображения: {e}")
            self.image_label.setStyleSheet("""
                font-size: 14px; color: red;
                padding: 20px; border: 1px dashed red;
            """)
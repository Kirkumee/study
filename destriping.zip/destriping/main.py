import sys
from PyQt5.QtWidgets import QApplication
from ui_main import MainMenu

if __name__ == "__main__":
    app = QApplication(sys.argv)
    app.setStyle("Fusion")
    win = MainMenu()
    win.show()
    sys.exit(app.exec_())
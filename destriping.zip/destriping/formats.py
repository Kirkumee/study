import struct
import numpy as np

def _to_uint8_stretch(arr: np.ndarray) -> np.ndarray:
    if arr.dtype == np.uint8:
        return arr
    arr_f = arr.astype(np.float32)
    lo, hi = arr_f.min(), arr_f.max()
    if hi == lo:
        return np.zeros_like(arr, dtype=np.uint8)
    return np.clip((arr_f - lo) / (hi - lo) * 255.0, 0, 255).astype(np.uint8)

def _normalize_shape(arr: np.ndarray):
    if arr.ndim == 2:
        return arr[:, :, np.newaxis], 1
    if arr.shape[2] == 4:
        return arr[:, :, :3].copy(), 3
    return arr, arr.shape[2]

def read_bmp(fname: str) -> dict:
    try:
        from PIL import Image
        with Image.open(fname) as im:
            if im.mode == "L":
                arr = np.array(im, dtype=np.uint8)[:, :, np.newaxis]
            else:
                arr = np.array(im.convert("RGB"), dtype=np.uint8)
    except ImportError:
        arr = _read_bmp_manual(fname)

    arr, c = _normalize_shape(arr)
    h, w = arr.shape[:2]
    return {"w": w, "h": h, "c": c, "bps": 8, "img": arr.copy()}

def _read_bmp_manual(fname: str) -> np.ndarray:
    with open(fname, "rb") as f:
        bmp = f.read()
    if bmp[:2] != b"BM":
        raise ValueError("Это не BMP файл")
    offset   = struct.unpack("<I", bmp[10:14])[0]
    w        = struct.unpack("<i", bmp[18:22])[0]
    h        = struct.unpack("<i", bmp[22:26])[0]
    bpp      = struct.unpack("<H", bmp[28:30])[0]
    if bpp not in (8, 24):
        raise ValueError("Поддерживается только 8 и 24-bit BMP")
    c        = 1 if bpp == 8 else 3
    abs_h    = abs(h)
    row_size = ((w * c + 3) // 4) * 4
    raw      = np.frombuffer(bmp, dtype=np.uint8, offset=offset)
    if c == 3:
        rows = raw[:abs_h * row_size].reshape(abs_h, row_size)
        bgr  = rows[:, :w * 3].reshape(abs_h, w, 3)
        arr  = bgr[:, :, ::-1].copy()
    else:
        rows = raw[:abs_h * row_size].reshape(abs_h, row_size)
        arr  = rows[:, :w, np.newaxis].copy()
    if h > 0:
        arr = arr[::-1].copy()
    return arr

def save_bmp(fname: str, data: dict) -> None:
    from PIL import Image
    img = data["img"]
    if not isinstance(img, np.ndarray):
        img = np.array(img, dtype=np.uint8)
    if img.ndim == 3 and img.shape[2] == 1:
        pil_img = Image.fromarray(img[:, :, 0], mode="L")
    else:
        pil_img = Image.fromarray(img[:, :, :3], mode="RGB")
    if not fname.lower().endswith(".bmp"):
        fname += ".bmp"
    pil_img.save(fname)

def read_tiff(fname: str) -> dict:
    from PIL import Image
    with Image.open(fname) as im:
        arr = np.array(im)

    bps = 16 if arr.dtype == np.uint16 else 8
    arr = _to_uint8_stretch(arr)
    arr, c = _normalize_shape(arr)
    h, w = arr.shape[:2]
    return {"w": w, "h": h, "c": c, "bps": bps, "img": arr.copy()}

def save_tiff(fname: str, data: dict) -> None:
    from PIL import Image
    img = data["img"]
    if not isinstance(img, np.ndarray):
        img = np.array(img, dtype=np.uint8)
    if img.ndim == 3 and img.shape[2] == 1:
        pil_img = Image.fromarray(img[:, :, 0], mode="L")
    else:
        pil_img = Image.fromarray(img[:, :, :3], mode="RGB")
    if not (fname.lower().endswith(".tif") or fname.lower().endswith(".tiff")):
        fname += ".tif"
    pil_img.save(fname)
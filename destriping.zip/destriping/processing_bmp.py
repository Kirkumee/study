import math
import numpy as np

def _to_np(img) -> np.ndarray:
    if isinstance(img, np.ndarray):
        arr = img.astype(np.float32)
    else:
        arr = np.array(img, dtype=np.float32)
    if arr.ndim == 2:
        arr = arr[:, :, np.newaxis]
    return arr


def _to_same_type(arr_uint8: np.ndarray, original_img) -> np.ndarray:
    return arr_uint8

def bmp_contrast_divide(img, w, h, c):
    arr = _to_np(img)
    out = np.clip(arr / 2.0, 0, 255).astype(np.uint8)
    return out

def bmp_negative(img, w, h, c):
    arr = _to_np(img)
    out = np.clip(255.0 - arr, 0, 255).astype(np.uint8)
    return out

def bmp_scale_thin(img, w, h, c, n):
    arr = _to_np(img).astype(np.uint8)
    new_h = h // n
    new_w = w // n
    out = arr[n // 2 : new_h * n : n,
               n // 2 : new_w * n : n, :]
    return out[:new_h, :new_w, :].copy(), new_w, new_h

def bmp_scale_avg(img, w, h, c, n):
    arr = _to_np(img)
    new_h = h // n
    new_w = w // n
    cropped = arr[:new_h * n, :new_w * n, :]
    out = cropped.reshape(new_h, n, new_w, n, arr.shape[2]).mean(axis=(1, 3))
    return np.clip(out, 0, 255).astype(np.uint8), new_w, new_h

def _rotate_numpy(img, w, h, c, angle_deg, order=0):
    arr = _to_np(img)
    t  = math.radians(angle_deg)
    ct, st = math.cos(t), math.sin(t)
    cx, cy = (w - 1) / 2.0, (h - 1) / 2.0

    ys, xs = np.mgrid[0:h, 0:w]
    fx = ct * (xs - cx) + st * (ys - cy) + cx
    fy = -st * (xs - cx) + ct * (ys - cy) + cy

    out = np.zeros((h, w, arr.shape[2]), dtype=np.float32)

    if order == 0:
        ix = np.round(fx).astype(np.int32)
        iy = np.round(fy).astype(np.int32)
        mask = (ix >= 0) & (ix < w) & (iy >= 0) & (iy < h)
        out[mask] = arr[iy[mask], ix[mask]]
    else:
        x1 = np.floor(fx).astype(np.int32)
        y1 = np.floor(fy).astype(np.int32)
        x2 = x1 + 1
        y2 = y1 + 1
        dx = (fx - x1).astype(np.float32)
        dy = (fy - y1).astype(np.float32)
        mask = (x1 >= 0) & (x2 < w) & (y1 >= 0) & (y2 < h)
        for ch in range(arr.shape[2]):
            p = arr[:, :, ch]
            v = np.zeros((h, w), dtype=np.float32)
            v[mask] = (
                p[y1[mask], x1[mask]] * (1 - dx[mask]) * (1 - dy[mask]) +
                p[y1[mask], x2[mask]] *      dx[mask]  * (1 - dy[mask]) +
                p[y2[mask], x1[mask]] * (1 - dx[mask]) *      dy[mask]  +
                p[y2[mask], x2[mask]] *      dx[mask]  *      dy[mask]
            )
            out[:, :, ch] = v
    return np.clip(out, 0, 255).astype(np.uint8)

def bmp_rotate_affine(img, w, h, c, angle_deg):
    return _rotate_numpy(img, w, h, c, angle_deg, order=0)

def bmp_rotate_bilinear(img, w, h, c, angle_deg):
    return _rotate_numpy(img, w, h, c, angle_deg, order=1)

def bmp_mean_filter(img, w, h, c, k):
    arr = _to_np(img).astype(np.uint8)
    try:
        from scipy.ndimage import uniform_filter
        out = np.stack(
            [uniform_filter(arr[:, :, ch].astype(np.float32), size=k)
             for ch in range(arr.shape[2])],
            axis=2
        )
    except ImportError:
        pad = k // 2
        arr_f = arr.astype(np.float32)
        arr_p = np.pad(arr_f, ((pad, pad), (pad, pad), (0, 0)), mode='reflect')
        out = sum(
            arr_p[dy: dy + h, dx: dx + w, :]
            for dy in range(k) for dx in range(k)
        ) / (k * k)

    return np.clip(out, 0, 255).astype(np.uint8)

def bmp_median_filter(img, w, h, c, k):
    arr = _to_np(img).astype(np.uint8)
    try:
        from scipy.ndimage import median_filter
        out = np.stack(
            [median_filter(arr[:, :, ch], size=k) for ch in range(arr.shape[2])],
            axis=2
        )
    except ImportError:
        from numpy.lib.stride_tricks import sliding_window_view
        pad = k // 2
        arr_p = np.pad(arr.astype(np.float32), ((pad, pad), (pad, pad), (0, 0)), mode='reflect')
        windows = sliding_window_view(arr_p, (k, k, arr.shape[2]))
        out = np.median(windows.reshape(h, w, -1), axis=2)

    return np.clip(out, 0, 255).astype(np.uint8)

def bmp_convolution(img, w, h, c, A, M=1.0, O=0.0):
    arr = _to_np(img).astype(np.float64)
    kernel = np.array(A, dtype=np.float64)

    try:
        from scipy.ndimage import correlate
        out = np.stack(
            [correlate(arr[:, :, ch], kernel, mode='reflect')
             for ch in range(arr.shape[2])],
            axis=2
        )
    except ImportError:
        k = kernel.shape[0]
        pad = k // 2
        arr_p = np.pad(arr, ((pad, pad), (pad, pad), (0, 0)), mode='reflect')
        out = np.zeros_like(arr)
        for dy in range(k):
            for dx in range(k):
                out += kernel[dy, dx] * arr_p[dy: dy + h, dx: dx + w, :]

    out = np.clip(M * out + O, 0, 255).astype(np.uint8)
    return out

def bmp_mean_std(img, w, h, c):
    arr = _to_np(img)
    return [
        (float(arr[:, :, ch].mean()), float(arr[:, :, ch].std()))
        for ch in range(arr.shape[2])
    ]
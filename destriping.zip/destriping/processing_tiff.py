import math
import numpy as np

Z_PERCENT = 0.02

def _to_np(img):
    if isinstance(img, np.ndarray):
        arr = img.astype(np.float32)
    else:
        arr = np.array(img, dtype=np.float32)
    if arr.ndim == 2:
        arr = arr[:, :, np.newaxis]
    return arr

def _to_same_type(arr_uint8, original_img):
    if isinstance(original_img, np.ndarray):
        return arr_uint8
    return arr_uint8.tolist()

def _find_bounds_z(hist):
    total = hist.sum()
    limit = total * Z_PERCENT
    cumsum = np.cumsum(hist)
    x1_arr = np.where(cumsum >= limit)[0]
    x2_arr = np.where((total - cumsum) < limit)[0]
    x1 = int(x1_arr[0]) if len(x1_arr) else 0
    x2 = int(x2_arr[0]) if len(x2_arr) else len(hist) - 1
    return x1, max(x2, x1 + 1)

def _find_bounds_nonzero(hist):
    nz = np.where(hist > 0)[0]
    if len(nz) == 0:
        return 0, 1
    x1, x2 = int(nz[0]), int(nz[-1])
    return x1, max(x2, x1 + 1)

def _linear_stretch(arr, x1, x2):
    out = (arr - x1) * (255.0 / (x2 - x1))
    return np.clip(out, 0, 255).astype(np.uint8)

def tiff_contrast_divide(img, w, h, c):
    arr = _to_np(img)
    out = np.where(arr > 255, arr / 256.0, arr / 2.0)
    return _to_same_type(np.clip(out, 0, 255).astype(np.uint8), img)

def tiff_contrast_linear_z(img, w, h, c):
    arr = _to_np(img)
    out = np.zeros(arr.shape, dtype=np.uint8)
    for ch in range(arr.shape[2]):
        plane = arr[:, :, ch]
        hist, _ = np.histogram(plane.ravel(), bins=65536, range=(0, 65535))
        x1, x2 = _find_bounds_z(hist)
        out[:, :, ch] = _linear_stretch(plane, x1, x2)
    return _to_same_type(out, img)

def tiff_contrast_linear_nz(img, w, h, c):
    arr = _to_np(img)
    out = np.zeros(arr.shape, dtype=np.uint8)
    for ch in range(arr.shape[2]):
        plane = arr[:, :, ch]
        hist, _ = np.histogram(plane.ravel(), bins=65536, range=(0, 65535))
        x1, x2 = _find_bounds_nonzero(hist)
        out[:, :, ch] = _linear_stretch(plane, x1, x2)
    return _to_same_type(out, img)

def tiff_negative(img, w, h, c):
    arr = _to_np(img)
    if arr.max() > 255:
        arr = arr / 65535.0 * 255.0
    return _to_same_type((255 - np.clip(arr, 0, 255)).astype(np.uint8), img)

def tiff_scale_avg(img, w, h, c, n):
    arr = _to_np(img)
    new_h = h // n
    new_w = w // n
    arr = arr[:new_h * n, :new_w * n, :]
    out = arr.reshape(new_h, n, new_w, n, arr.shape[2]).mean(axis=(1, 3))
    result = np.clip(out, 0, 255).astype(np.uint8)
    return _to_same_type(result, img), new_w, new_h

def tiff_rotate_bilinear(img, w, h, c, angle_deg):
    arr = _to_np(img)
    if arr.max() > 255:
        arr = arr / 65535.0 * 255.0

    t = math.radians(angle_deg)
    ct, st = math.cos(t), math.sin(t)
    cx, cy = (w - 1) / 2.0, (h - 1) / 2.0

    ys, xs = np.mgrid[0:h, 0:w]
    fx = ct * (xs - cx) + st * (ys - cy) + cx
    fy = -st * (xs - cx) + ct * (ys - cy) + cy

    x1 = np.floor(fx).astype(np.int32)
    y1 = np.floor(fy).astype(np.int32)
    x2 = x1 + 1
    y2 = y1 + 1
    dx = (fx - x1).astype(np.float32)
    dy = (fy - y1).astype(np.float32)

    mask = (x1 >= 0) & (x2 < w) & (y1 >= 0) & (y2 < h)
    out = np.zeros((h, w, arr.shape[2]), dtype=np.float32)
    for ch in range(arr.shape[2]):
        p = arr[:, :, ch]
        v = np.zeros((h, w), dtype=np.float32)
        v[mask] = (
            p[y1[mask], x1[mask]] * (1 - dx[mask]) * (1 - dy[mask]) +
            p[y1[mask], x2[mask]] * dx[mask] * (1 - dy[mask]) +
            p[y2[mask], x1[mask]] * (1 - dx[mask]) * dy[mask] +
            p[y2[mask], x2[mask]] * dx[mask] * dy[mask]
        )
        out[:, :, ch] = v
    return _to_same_type(np.clip(out, 0, 255).astype(np.uint8), img)

def tiff_median_filter(img, w, h, c, k):
    try:
        from scipy.ndimage import median_filter
        arr = _to_np(img)
        if arr.max() > 255:
            arr = arr / 65535.0 * 255.0
        arr = np.clip(arr, 0, 255).astype(np.uint8)
        out = np.stack([median_filter(arr[:, :, ch], size=k) for ch in range(arr.shape[2])], axis=2)
        return _to_same_type(out, img)
    except ImportError:
        arr = _to_np(img)
        if arr.max() > 255:
            arr = arr / 65535.0 * 255.0
        arr = np.clip(arr, 0, 255).astype(np.uint8)
        pad = k // 2
        arr_pad = np.pad(arr, ((pad, pad), (pad, pad), (0, 0)), mode='reflect')
        patches = np.stack([arr_pad[dy:dy+h, dx:dx+w, :] for dy in range(k) for dx in range(k)], axis=0)
        return _to_same_type(np.median(patches, axis=0).astype(np.uint8), img)

def tiff_convolution_smooth(img, w, h, c):
    try:
        from scipy.ndimage import uniform_filter
        arr = _to_np(img)
        if arr.max() > 255:
            arr = arr / 65535.0 * 255.0
        arr = np.clip(arr, 0, 255).astype(np.float32)
        out = np.stack([uniform_filter(arr[:, :, ch], size=3) for ch in range(arr.shape[2])], axis=2)
        return _to_same_type(np.clip(out, 0, 255).astype(np.uint8), img)
    except ImportError:
        arr = _to_np(img)
        if arr.max() > 255:
            arr = arr / 65535.0 * 255.0
        arr = np.clip(arr, 0, 255).astype(np.float32)
        arr_pad = np.pad(arr, ((1, 1), (1, 1), (0, 0)), mode='reflect')
        out = sum(arr_pad[dy:dy+h, dx:dx+w, :] for dy in range(3) for dx in range(3)) / 9.0
        return _to_same_type(np.clip(out, 0, 255).astype(np.uint8), img)

def tiff_mean_std(img, w, h, c):
    arr = _to_np(img)
    if arr.max() > 255:
        arr = arr / 65535.0 * 255.0
    return [(float(arr[:, :, ch].mean()), float(arr[:, :, ch].std())) for ch in range(arr.shape[2])]